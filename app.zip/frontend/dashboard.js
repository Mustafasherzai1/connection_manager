const API_DASHBOARD = String(window.API_DASHBOARD || "").replace(/\/+$/, "");

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(message, type = "info") {
  const wrap = $("toastWrap");
  if (!wrap) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function setStatus(message, loading = false) {
  const box = $("dashboardStatus");
  if (!box) return;
  box.innerHTML = loading
    ? `<span class="spinner"></span><span>${escapeHtml(message || "")}</span>`
    : escapeHtml(message || "");
}

function cardHtml(label, value, hint, target) {
  const href = target || "#";
  return `
    <a class="dashboard-card" href="${escapeHtml(href)}">
      <div class="small muted">${escapeHtml(label)}</div>
      <div class="dashboard-value">${escapeHtml(value)}</div>
      <div class="small muted">${escapeHtml(hint || "")}</div>
    </a>
  `;
}

function render(stats) {
  const grid = $("dashboardGrid");
  if (!grid) return;

  const cards = [
    cardHtml("Active Lines", stats.active_lines || 0, "Aktive Leitungen", "cross-connects.html?status=active"),
    cardHtml("Pending Install", stats.pending_install || 0, "Offene Installationen", "cross-connects.html?status=pending_install"),
    cardHtml("Pending Deinstall", stats.pending_deinstall || 0, "Offene Deinstallationen", "cross-connects.html?status=pending_deinstall"),
    cardHtml("Pending Move", stats.pending_move || 0, "Offene Moves", "cross-connects.html?status=pending_move"),
    cardHtml("Pending Path Move", stats.pending_path_move || 0, "Offene Path Moves", "cross-connects.html?status=pending_path_move"),
  ];

  grid.innerHTML = cards.join("\n");
}

async function loadDashboard() {
  setStatus("Dashboard wird geladen...", true);
  try {
    const res = await fetch(`${API_DASHBOARD}/stats`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
    render(data.stats || {});
    setStatus("Dashboard geladen");
  } catch (error) {
    setStatus(`Fehler: ${error.message}`);
    toast(`Dashboard konnte nicht geladen werden: ${error.message}`, "error");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  $("btnRefreshDashboard")?.addEventListener("click", loadDashboard);
  loadDashboard();
});
