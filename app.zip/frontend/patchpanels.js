const API_PATCHPANELS = String(window.API_PATCHPANELS || "").replace(/\/+$/, "");
const ALL_ROOMS = "__all__";

const state = {
  rooms: [],
  currentRoom: "",
  items: [],
  filtered: [],
  selectedId: null,
  selectedPanel: null,
  ports: [],
  selectedPortNumber: null,
  view: "grid",
};

const $ = (id) => document.getElementById(id);

function cassetteLabelFromPortNumber(portNumber) {
  const n = Number(portNumber || 0);
  if (!Number.isFinite(n) || n < 1) return "-";

  const cassetteIndex = Math.floor((n - 1) / 24) + 1;
  const within = (n - 1) % 24;
  const groupIndex = Math.floor(within / 6);
  const pos = (within % 6) + 1;
  const letters = ["A", "B", "C", "D"];
  const letter = letters[groupIndex] || "A";
  return `${cassetteIndex}${letter}${pos}`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(message, type = "info") {
  const wrap = $("toastWrap");
  if (!wrap) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function setStatus(message) {
  const box = $("panelStatus");
  if (box) box.textContent = message || "";
}

async function apiJson(url) {
  const res = await fetch(url);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
  return data;
}

function selectedRoomValue() {
  return String($("roomFilter")?.value || "").trim();
}

function selectedRoomLabel() {
  const value = selectedRoomValue();
  if (!value) return "";
  if (value === ALL_ROOMS) return "Alle Raeume";
  return value;
}

function setRoomCounter() {
  const box = $("roomCounter");
  if (!box) return;
  const value = selectedRoomValue();
  if (!value) {
    box.textContent = "Bitte zuerst Raum auswaehlen.";
    return;
  }
  const label = selectedRoomLabel();
  box.textContent = `Patchpanels in Raum ${label}: ${state.filtered.length}`;
}

function setRoomHint() {
  const hint = $("roomHint");
  if (!hint) return;
  const value = selectedRoomValue();
  if (!value) {
    hint.style.display = "block";
    hint.textContent = "Bitte zuerst Raum auswaehlen.";
    return;
  }
  hint.style.display = "none";
}

function filterList() {
  const q = ($("patchpanelSearch")?.value || "").trim().toLowerCase();
  state.filtered = state.items.filter((item) => {
    if (!q) return true;
    const hay = `${item.name || ""} ${item.location || ""} ${item.room || ""}`.toLowerCase();
    return hay.includes(q);
  });
}

function renderList() {
  const box = $("patchpanelList");
  if (!box) return;
  box.innerHTML = "";

  const room = selectedRoomValue();
  if (!room) {
    box.innerHTML = '<div class="small muted" style="padding:8px 4px;">Bitte zuerst Raum auswaehlen.</div>';
    setRoomCounter();
    setRoomHint();
    return;
  }

  if (!state.filtered.length) {
    box.innerHTML = '<div class="small muted" style="padding:8px 4px;">Keine Patchpanels gefunden.</div>';
    setRoomCounter();
    setRoomHint();
    return;
  }

  for (const item of state.filtered) {
    const el = document.createElement("a");
    el.href = "#";
    el.className = `list-group-item ${Number(item.id) === Number(state.selectedId) ? "active" : ""}`;
    el.innerHTML = `
      <div style="font-weight:700;">${escapeHtml(item.name || `Patchpanel ${item.id}`)}</div>
      <div class="small muted">${escapeHtml(item.location || "-")} | ${escapeHtml(String(item.ports_total || "-"))} Ports</div>
    `;
    el.addEventListener("click", (ev) => {
      ev.preventDefault();
      selectPanel(item.id);
    });
    box.appendChild(el);
  }
  setRoomCounter();
  setRoomHint();
}

function statusBadge(isOccupied) {
  return isOccupied
    ? '<span class="badge badge-warning">belegt</span>'
    : '<span class="badge badge-neutral">frei</span>';
}

function statusBadgeFromPort(port) {
  if (String(port?.status || "").toLowerCase() === "unavailable") {
    return '<span class="badge badge-danger">n/a</span>';
  }
  return statusBadge(!!port?.is_occupied);
}

function renderPortDetail(port) {
  const box = $("portDetail");
  if (!box) return;
  if (!port) {
    box.innerHTML = '<div class="small muted">Port auswaehlen, um Details anzuzeigen.</div>';
    return;
  }
  const numericPort = Number(port.port_number || 0) || "-";
  const cassetteLabel = cassetteLabelFromPortNumber(port.port_number);
  const titlePort = `${cassetteLabel}`;

  if (!port.is_occupied) {
    if (String(port.status || "").toLowerCase() === "unavailable") {
      box.innerHTML = `
        <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(titlePort)}</div>
        <div class="small muted">Portnummer: ${escapeHtml(String(numericPort))}</div>
        <div class="small muted">Status: nicht verfuegbar</div>
      `;
      return;
    }
    box.innerHTML = `
      <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(titlePort)}</div>
      <div class="small muted">Portnummer: ${escapeHtml(String(numericPort))}</div>
      <div class="small muted">Status: frei</div>
    `;
    return;
  }

  const searchLink = port.serial
    ? `cross-connects.html?q=${encodeURIComponent(port.serial)}`
    : "cross-connects.html";
  box.innerHTML = `
    <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(titlePort)}</div>
    <div class="small muted"><b>Portnummer:</b> ${escapeHtml(String(numericPort))}</div>
    <div class="small"><b>Status:</b> belegt</div>
    <div class="small"><b>Serial:</b> <span class="mono">${escapeHtml(port.serial || "-")}</span></div>
    <div class="small"><b>Kunde:</b> ${escapeHtml(port.customer || "-")}</div>
    <div class="small"><b>Side:</b> ${escapeHtml(port.side || "-")}</div>
    <div style="margin-top:8px;"><a class="btn" href="${escapeHtml(searchLink)}">Open Cross Connect</a></div>
  `;
}

function onPortSelected(port) {
  state.selectedPortNumber = Number(port.port_number || 0);
  renderPortDetail(port);
  renderCassettes();
  renderTable();
}

function renderCassettes() {
  const wrap = $("cassetteWrap");
  if (!wrap) return;
  wrap.innerHTML = "";

  const total = Number(state.selectedPanel?.ports_total || 0);
  const ports = Array.isArray(state.ports) ? state.ports : [];
  if (!total || !ports.length) {
    wrap.innerHTML = '<div class="small muted">Keine Portdaten vorhanden.</div>';
    return;
  }
  const portMap = new Map();
  for (const p of ports) {
    portMap.set(Number(p.port_number || 0), p);
  }

  const cassetteCount = Math.ceil(total / 24);
  const host = document.createElement("div");
  host.className = "cassette-host";

  for (let c = 0; c < cassetteCount; c += 1) {
    const start = c * 24 + 1;
    const end = Math.min(start + 23, total);
    const cassetteNo = c + 1;
    const cassetteStartLabel = `${cassetteNo}A1`;
    const cassetteEndLabel = `${cassetteNo}D6`;

    const card = document.createElement("div");
    card.className = "cassette-card";
    card.innerHTML = `<div class="cassette-title">Cassette ${cassetteNo} (${cassetteStartLabel}-${cassetteEndLabel})</div>`;

    const grid = document.createElement("div");
    grid.className = "cassette-grid";

    for (let p = start; p <= end; p += 1) {
      const port = portMap.get(p) || { port_number: p, is_occupied: false, status: "free" };
      const cassetteLabel = cassetteLabelFromPortNumber(p);
      const btn = document.createElement("button");
      const occ = !!port?.is_occupied;
      const unavailable = String(port?.status || "").toLowerCase() === "unavailable";
      const isSelected = Number(port?.port_number || 0) === Number(state.selectedPortNumber || 0);
      btn.className = `port-tile ${unavailable ? "unavailable" : (occ ? "occupied" : "free")} ${isSelected ? "selected" : ""}`;
      btn.type = "button";
      btn.innerHTML = `
        <span>${escapeHtml(cassetteLabel)}</span>
        <span class="dot"></span>
      `;
      btn.title = `Port ${cassetteLabel} (#${p}) (${unavailable ? "n/a" : (occ ? "belegt" : "frei")})`;
      if (!unavailable) {
        btn.addEventListener("click", () => onPortSelected(port));
      } else {
        btn.disabled = true;
      }
      grid.appendChild(btn);
    }

    card.appendChild(grid);
    host.appendChild(card);
  }

  wrap.appendChild(host);
}

function renderTable() {
  const body = $("portsTableBody");
  if (!body) return;
  body.innerHTML = "";
  for (const port of state.ports) {
    const cassetteLabel = cassetteLabelFromPortNumber(port.port_number);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(String(port.port_number || "-"))}</td>
      <td>${escapeHtml(cassetteLabel)}</td>
      <td>${statusBadgeFromPort(port)}</td>
      <td class="mono">${escapeHtml(port.serial || "-")}</td>
      <td>${escapeHtml(port.customer || "-")}</td>
      <td>${escapeHtml(port.side || "-")}</td>
    `;
    if (String(port.status || "").toLowerCase() !== "unavailable") {
      tr.addEventListener("click", () => onPortSelected(port));
    }
    body.appendChild(tr);
  }
}

function renderSelectionMeta() {
  const title = $("selectedPanelTitle");
  const meta = $("selectedPanelMeta");
  if (!state.selectedPanel) {
    if (title) title.textContent = "Kein Patchpanel ausgewaehlt";
    if (meta) meta.textContent = "Bitte links ein Patchpanel waehlen.";
    return;
  }

  if (title) title.textContent = state.selectedPanel.name || `Patchpanel ${state.selectedPanel.id}`;
  if (meta) {
    meta.textContent = `${state.selectedPanel.location || "-"} | ${state.selectedPanel.ports_total || "-"} Ports`;
  }
}

function applyView() {
  const showGrid = state.view === "grid";
  $("cassetteWrap").style.display = showGrid ? "block" : "none";
  $("portsTableWrap").style.display = showGrid ? "none" : "block";

  $("btnViewGrid").classList.toggle("btn-secondary", showGrid);
  $("btnViewGrid").classList.toggle("btn", true);
  $("btnViewTable").classList.toggle("btn-secondary", !showGrid);
  $("btnViewTable").classList.toggle("btn", true);
}

async function selectPanel(panelId) {
  state.selectedId = Number(panelId || 0);
  if (!state.selectedId) return;
  setStatus("Patchpanel wird geladen...");
  try {
    const data = await apiJson(`${API_PATCHPANELS}/${state.selectedId}/ports`);
    state.selectedPanel = data.patchpanel || null;
    state.ports = Array.isArray(data.ports) ? data.ports : [];
    state.selectedPortNumber = null;
    renderSelectionMeta();
    renderList();
    renderCassettes();
    renderTable();
    renderPortDetail(null);
    applyView();
    setStatus("Patchpanel geladen");
  } catch (error) {
    setStatus(`Fehler: ${error.message}`);
    toast(`Patchpanel konnte nicht geladen werden: ${error.message}`, "error");
  }
}

function clearPanelSelection() {
  state.selectedId = null;
  state.selectedPanel = null;
  state.ports = [];
  state.selectedPortNumber = null;
  renderSelectionMeta();
  renderCassettes();
  renderTable();
  renderPortDetail(null);
}

async function loadPatchpanelsByRoom() {
  const room = selectedRoomValue();
  if (!room) {
    state.currentRoom = "";
    state.items = [];
    state.filtered = [];
    clearPanelSelection();
    renderList();
    setStatus("Bitte zuerst Raum auswaehlen.");
    return;
  }

  state.currentRoom = room;
  setStatus("Patchpanels werden geladen...");
  try {
    const query = room === ALL_ROOMS ? "" : `?room=${encodeURIComponent(room)}`;
    const data = await apiJson(`${API_PATCHPANELS}${query}`);
    state.items = Array.isArray(data.items) ? data.items : [];
    filterList();

    if (!state.filtered.some((x) => Number(x.id) === Number(state.selectedId || 0))) {
      clearPanelSelection();
    }

    renderList();
    if (!state.selectedId && state.filtered.length) {
      await selectPanel(state.filtered[0].id);
    } else {
      renderSelectionMeta();
      setStatus("Patchpanels geladen");
    }
    setRoomCounter();
  } catch (error) {
    setStatus(`Fehler: ${error.message}`);
    toast(`Patchpanel-Liste konnte nicht geladen werden: ${error.message}`, "error");
  }
}

async function loadRooms() {
  setStatus("Raeume werden geladen...");
  try {
    const data = await apiJson(`${API_PATCHPANELS}/rooms`);
    const rooms = Array.isArray(data.rooms) ? data.rooms : [];
    state.rooms = rooms;

    const select = $("roomFilter");
    if (select) {
      const previous = String(select.value || "");
      select.innerHTML = "";

      const optChoose = document.createElement("option");
      optChoose.value = "";
      optChoose.textContent = "Bitte Raum waehlen";
      select.appendChild(optChoose);

      const optAll = document.createElement("option");
      optAll.value = ALL_ROOMS;
      optAll.textContent = "Alle Raeume";
      select.appendChild(optAll);

      for (const room of rooms) {
        const opt = document.createElement("option");
        opt.value = room;
        opt.textContent = room;
        select.appendChild(opt);
      }

      const keep = previous && (previous === ALL_ROOMS || rooms.includes(previous)) ? previous : "";
      select.value = keep;
    }
    setStatus("Raeume geladen");
    await loadPatchpanelsByRoom();
  } catch (error) {
    setStatus(`Fehler: ${error.message}`);
    toast(`Raeume konnten nicht geladen werden: ${error.message}`, "error");
  }
}

function bindEvents() {
  $("roomFilter")?.addEventListener("change", loadPatchpanelsByRoom);

  $("patchpanelSearch")?.addEventListener("input", async () => {
    filterList();
    renderList();

    if (!state.filtered.some((x) => Number(x.id) === Number(state.selectedId || 0))) {
      clearPanelSelection();
      if (state.filtered.length) {
        await selectPanel(state.filtered[0].id);
      }
    }
    setRoomCounter();
  });

  $("btnRefreshPatchpanels")?.addEventListener("click", async () => {
    await loadRooms();
  });
  $("btnViewGrid")?.addEventListener("click", () => {
    state.view = "grid";
    applyView();
  });
  $("btnViewTable")?.addEventListener("click", () => {
    state.view = "table";
    applyView();
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  applyView();
  setRoomHint();
  setRoomCounter();
  clearPanelSelection();
  await loadRooms();
});
