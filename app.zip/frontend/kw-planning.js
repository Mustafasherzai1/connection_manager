const API_PLANS = String(window.API_KW_PLANS || "").replace(/\/+$/, "");
const API_TASKS = String(window.API_KW_TASKS || "").replace(/\/+$/, "");
const API_LINES = String(window.API_LINES || "").replace(/\/+$/, "");
const API_PATCHPANELS = String(window.API_PATCHPANELS || "").replace(/\/+$/, "");
const API_RFRA_PORTS = String(window.API_RFRA_PORTS || `${window.API_ROOT || ""}/rfra/ports`).replace(/\/+$/, "");
const API_BB_MIRROR = String(window.API_BB_MIRROR || `${window.API_ROOT || ""}/bb/mirror`).replace(/\/+$/, "");

const state = {
  plan: null,
  tasks: [],
  archivePlans: [],
  activeTab: "active",
  install: {
    rfraOptions: [],
    selectedRfra: null,
    bbInOptions: [],
    selectedBbInPp: null,
    selectedBbInPort: null,
    mirror: null,
    bbPortPicker: {
      panelId: null,
      panelMeta: null,
      ports: [],
      selectedPortNumber: null,
    },
  },
  lookups: {
    de: null,
    move: null,
    swap1: null,
    swap2: null,
  },
  lookupDebounce: {
    de: null,
    move: null,
    rfra: null,
  },
};

const ALLOWED_STATUS = [
  "pending_install",
  "pending_deinstall",
  "pending_move",
  "pending_path_move",
  "done",
  "cancelled",
];
const PLAN_READ_ONLY = new Set(["completed", "archived"]);

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(message, type = "info") {
  const wrap = $("toastWrap");
  if (!wrap) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3400);
}

function setPlanStatus(message) {
  const box = $("planStatus");
  if (box) box.textContent = message || "";
}

function setArchiveStatus(message) {
  const box = $("archiveStatus");
  if (box) box.textContent = message || "";
}

function getIsoWeek(date = new Date()) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return { year: d.getUTCFullYear(), week: weekNo };
}

function isPlanReadOnly(plan) {
  return PLAN_READ_ONLY.has(String(plan?.status || "").toLowerCase());
}

function canEditCurrentPlan() {
  const isAdmin = !!(window.isAdminRole && window.isAdminRole());
  return isAdmin && !!state.plan && !isPlanReadOnly(state.plan);
}

async function apiJson(url, options) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.detail || `HTTP ${res.status}`);
  }
  return data;
}

function statusBadge(status) {
  const s = String(status || "").toLowerCase();
  let cls = "badge-neutral";
  if (s === "done" || s === "active") cls = "badge-success";
  else if (s === "cancelled" || s === "archived") cls = "badge-danger";
  else cls = "badge-warning";
  return `<span class="badge ${cls}">${escapeHtml(status || "-")}</span>`;
}

function taskTypeBadge(type) {
  const t = String(type || "").toLowerCase();
  const mapping = {
    install: "Installation",
    deinstall: "Deinstallation",
    move: "Line Move",
    path_move: "Path Move",
  };
  return `<span class="badge badge-neutral">${escapeHtml(mapping[t] || t)}</span>`;
}

function linePreviewHtml(line, title = "Leitung") {
  if (!line) return `<div class="small muted">Keine Leitung geladen.</div>`;
  return `
    <div style="font-weight:700; margin-bottom:6px;">${escapeHtml(title)}</div>
    <div class="small"><b>Serial:</b> <span class="mono">${escapeHtml(line.serial || "-")}</span></div>
    <div class="small"><b>A-Seite:</b> ${escapeHtml(line.a_patchpanel_id || "-")} ${escapeHtml(line.a_port_label || "-")}</div>
    <div class="small"><b>BB IN:</b> ${escapeHtml(line.backbone_in_instance_id || "-")} ${escapeHtml(line.backbone_in_port_label || "-")}</div>
    <div class="small"><b>BB OUT:</b> ${escapeHtml(line.backbone_out_instance_id || "-")} ${escapeHtml(line.backbone_out_port_label || "-")}</div>
    <div class="small"><b>Z-Seite:</b> ${escapeHtml(line.rack_code || "-")} ${escapeHtml(line.z_pp_number || line.customer_patchpanel_id || "-")} ${escapeHtml(line.customer_port_label || "-")}</div>
    <div class="small"><b>Status:</b> ${escapeHtml(line.status || "-")}</div>
  `;
}

function formatTs(value) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString("de-DE", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function parseNum(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function isPortUnavailable(port) {
  return String(port?.status || "").toLowerCase() === "unavailable";
}

function isPortOccupied(port) {
  return !!(port?.is_occupied || port?.occupied || port?.trunk_present);
}

function setInstallStatus(message) {
  const box = $("instRfraStatus");
  if (box) box.textContent = message || "";
}

function setMirrorStatus(message) {
  const box = $("instBbMirrorStatus");
  if (box) box.textContent = message || "";
}

function clearBbPortSelection() {
  state.install.selectedBbInPort = null;
  state.install.bbPortPicker.selectedPortNumber = null;
  $("instBbInPort").value = "";
}

function clearMirrorSelection() {
  state.install.mirror = null;
  $("instBbOutPp").value = "";
  $("instBbOutPort").value = "";
  setMirrorStatus("BB OUT wird nach BB IN Portwahl automatisch gesetzt.");
}

function resetInstallChainFromRfra() {
  state.install.bbInOptions = [];
  state.install.selectedBbInPp = null;
  $("instBbInPp").innerHTML = '<option value="">Bitte BB IN Patchpanel waehlen</option>';
  clearBbPortSelection();
  clearMirrorSelection();
}

function renderRfraOptions() {
  const select = $("instRfraSelect");
  if (!select) return;
  const options = Array.isArray(state.install.rfraOptions) ? state.install.rfraOptions : [];
  const selectedId = Number(state.install.selectedRfra?.rfra_id || state.install.selectedRfra?.id || 0);

  select.innerHTML = '<option value="">Bitte RFRA Port waehlen</option>';
  for (const item of options) {
    const id = Number(item.rfra_id || item.id || 0);
    const option = document.createElement("option");
    option.value = String(id);
    option.textContent = item.label || `${item.switch_name || "-"} ${item.switch_port || "-"}`;
    if (id && id === selectedId) option.selected = true;
    select.appendChild(option);
  }
}

function renderBbInOptions() {
  const select = $("instBbInPp");
  if (!select) return;
  const options = Array.isArray(state.install.bbInOptions) ? state.install.bbInOptions : [];
  const selectedId = Number(state.install.selectedBbInPp?.id || 0);

  select.innerHTML = '<option value="">Bitte BB IN Patchpanel waehlen</option>';
  for (const item of options) {
    const id = Number(item.id || item.bb_in_pp_id || 0);
    const option = document.createElement("option");
    option.value = String(id);
    option.textContent = item.label || item.bb_in_pp_name || item.instance_id || `Patchpanel ${id}`;
    if (id && id === selectedId) option.selected = true;
    select.appendChild(option);
  }
}

async function searchRfraOptions() {
  const query = String($("instRfraQuery")?.value || "").trim();
  setInstallStatus("RFRA Ports werden geladen...");
  try {
    const url = new URL(API_RFRA_PORTS, window.location.origin);
    if (query) url.searchParams.set("q", query);
    url.searchParams.set("limit", "80");
    const data = await apiJson(url.toString());
    state.install.rfraOptions = Array.isArray(data.items) ? data.items : [];
    const selectedId = Number(state.install.selectedRfra?.rfra_id || state.install.selectedRfra?.id || 0);
    if (selectedId && !state.install.rfraOptions.some((x) => Number(x.rfra_id || x.id || 0) === selectedId)) {
      state.install.selectedRfra = null;
      $("instRfraRoom").value = "";
      $("instASidePp").value = "";
      $("instASidePort").value = "";
      resetInstallChainFromRfra();
    }
    renderRfraOptions();
    setInstallStatus(`${state.install.rfraOptions.length} RFRA Port(s) gefunden`);
    updateLookupButtons();
  } catch (error) {
    state.install.rfraOptions = [];
    renderRfraOptions();
    setInstallStatus(`RFRA Suche fehlgeschlagen: ${error.message}`);
    toast(`RFRA Suche fehlgeschlagen: ${error.message}`, "error");
  }
}

function applySelectedRfraToFields(item) {
  const room = String(item?.room || "").trim();
  const aSidePp = String(item?.a_side_pp_name || item?.a_side_pp_id || "").trim();
  const aSidePort = String(item?.a_side_port_label || "").trim();
  $("instRfraRoom").value = room;
  $("instASidePp").value = aSidePp;
  $("instASidePort").value = aSidePort;
}

async function loadBbInOptionsForSelectedRfra() {
  const rfra = state.install.selectedRfra;
  if (!rfra) {
    state.install.bbInOptions = [];
    renderBbInOptions();
    return;
  }

  setInstallStatus("BB IN Patchpanels werden geladen...");
  try {
    const rfraId = Number(rfra.rfra_id || rfra.id || 0);
    const data = await apiJson(`${API_RFRA_PORTS}/${rfraId}/bb-options`);
    state.install.bbInOptions = Array.isArray(data.options) ? data.options : [];
    renderBbInOptions();
    setInstallStatus(`${state.install.bbInOptions.length} BB IN Patchpanel(s) im RFRA Raum gefunden`);
    if (!state.install.bbInOptions.length) {
      setMirrorStatus("Keine BB IN Patchpanels fuer diesen RFRA Raum gefunden.");
    }
  } catch (error) {
    state.install.bbInOptions = [];
    renderBbInOptions();
    setInstallStatus(`BB IN Optionen fehlgeschlagen: ${error.message}`);
    toast(`BB IN Optionen konnten nicht geladen werden: ${error.message}`, "error");
  }
}

async function onRfraSelected() {
  const selectedId = Number($("instRfraSelect").value || 0);
  const selected = state.install.rfraOptions.find((x) => Number(x.rfra_id || x.id || 0) === selectedId) || null;
  state.install.selectedRfra = selected;

  resetInstallChainFromRfra();
  if (!selected) {
    $("instRfraRoom").value = "";
    $("instASidePp").value = "";
    $("instASidePort").value = "";
    setInstallStatus("Bitte RFRA Port auswaehlen.");
    updateLookupButtons();
    return;
  }

  applySelectedRfraToFields(selected);
  await loadBbInOptionsForSelectedRfra();
  updateLookupButtons();
}

function onBbInPatchpanelChanged() {
  const selectedId = Number($("instBbInPp").value || 0);
  state.install.selectedBbInPp = state.install.bbInOptions.find((x) => Number(x.id || x.bb_in_pp_id || 0) === selectedId) || null;
  clearBbPortSelection();
  clearMirrorSelection();
  updateLookupButtons();
}

function bbPortBadge(port) {
  if (isPortUnavailable(port)) return '<span class="badge badge-danger">n/a</span>';
  if (isPortOccupied(port)) return '<span class="badge badge-warning">belegt</span>';
  return '<span class="badge badge-success">frei</span>';
}

function renderBbPortDetail(port) {
  const box = $("bbPortDetail");
  if (!box) return;
  if (!port) {
    box.innerHTML = '<div class="small muted">Port auswaehlen, um Details zu sehen.</div>';
    return;
  }
  const label = port.port_label || port.port_number || "-";
  const number = port.port_number || "-";
  if (isPortUnavailable(port)) {
    box.innerHTML = `<div class="small muted">Port ${escapeHtml(label)} (#${escapeHtml(String(number))}) ist nicht verfuegbar.</div>`;
    return;
  }
  if (!isPortOccupied(port)) {
    box.innerHTML = `
      <div class="small"><b>Port:</b> ${escapeHtml(label)} (#${escapeHtml(String(number))})</div>
      <div class="small"><b>Status:</b> frei</div>
      <div class="small muted">Port kann fuer BB IN verwendet werden.</div>
    `;
    return;
  }
  box.innerHTML = `
    <div class="small"><b>Port:</b> ${escapeHtml(label)} (#${escapeHtml(String(number))})</div>
    <div class="small"><b>Status:</b> belegt</div>
    <div class="small"><b>Serial:</b> <span class="mono">${escapeHtml(port.serial || "-")}</span></div>
    <div class="small"><b>Kunde:</b> ${escapeHtml(port.customer || "-")}</div>
    <div class="small"><b>Side:</b> ${escapeHtml(port.side || "-")}</div>
  `;
}

function renderBbPortGrid() {
  const grid = $("bbPortGrid");
  if (!grid) return;
  grid.innerHTML = "";

  const ports = Array.isArray(state.install.bbPortPicker.ports) ? state.install.bbPortPicker.ports : [];
  for (const port of ports) {
    const unavailable = isPortUnavailable(port);
    const occupied = isPortOccupied(port);
    const blocked = unavailable || occupied;
    const selected = Number(port.port_number || 0) === Number(state.install.bbPortPicker.selectedPortNumber || 0);

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `zport-tile ${unavailable ? "unavailable" : (occupied ? "occupied" : "free")} ${blocked ? "blocked" : ""} ${selected ? "selected" : ""}`;
    btn.innerHTML = `<span>${escapeHtml(port.port_label || String(port.port_number || "-"))}</span><span class="dot"></span>`;
    btn.title = unavailable ? "Port nicht verfuegbar" : (occupied ? "Port belegt" : "Port frei");
    btn.addEventListener("mouseenter", () => renderBbPortDetail(port));
    btn.addEventListener("click", () => onBbPortClicked(port));
    grid.appendChild(btn);
  }
}

function renderBbPortTable() {
  const body = $("bbPortTableBody");
  if (!body) return;
  body.innerHTML = "";

  const ports = Array.isArray(state.install.bbPortPicker.ports) ? state.install.bbPortPicker.ports : [];
  for (const port of ports) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(String(port.port_number || "-"))}</td>
      <td>${escapeHtml(port.port_label || "-")}</td>
      <td>${bbPortBadge(port)}</td>
      <td class="mono">${escapeHtml(port.serial || "-")}</td>
      <td>${escapeHtml(port.customer || "-")}</td>
      <td>${escapeHtml(port.side || "-")}</td>
    `;
    tr.addEventListener("mouseenter", () => renderBbPortDetail(port));
    tr.addEventListener("click", () => onBbPortClicked(port));
    body.appendChild(tr);
  }
}

function closeBbPortPicker() {
  $("bbPortBackdrop").style.display = "none";
}

async function openBbPortPicker() {
  const selected = state.install.selectedBbInPp;
  if (!selected) {
    toast("Bitte zuerst BB IN Patchpanel auswaehlen", "error");
    return;
  }

  const panelId = Number(selected.id || selected.bb_in_pp_id || 0);
  const panelName = selected.bb_in_pp_name || selected.instance_id || `Patchpanel ${panelId}`;
  state.install.bbPortPicker.panelId = panelId;
  state.install.bbPortPicker.panelMeta = { id: panelId, name: panelName };
  state.install.bbPortPicker.ports = [];
  state.install.bbPortPicker.selectedPortNumber = null;

  $("bbPortBackdrop").style.display = "block";
  $("bbPortTitle").textContent = `BB IN Port Auswahl - ${panelName}`;
  $("bbPortPanelMeta").textContent = `${panelName} | Patchpanel ID ${panelId}`;
  $("bbPortStatus").textContent = "Ports werden geladen...";
  renderBbPortDetail(null);

  try {
    const data = await apiJson(`${API_PATCHPANELS}/${panelId}/ports`);
    const ports = Array.isArray(data.ports) ? data.ports.slice() : [];
    ports.sort((a, b) => Number(a.port_number || 0) - Number(b.port_number || 0));
    state.install.bbPortPicker.ports = ports;

    const currentPort = String($("instBbInPort").value || "").trim().toLowerCase();
    const selectedPort = ports.find((p) => {
      const label = String(p.port_label || "").trim().toLowerCase();
      const number = String(p.port_number || "").trim().toLowerCase();
      return currentPort && (currentPort === label || currentPort === number);
    });
    state.install.bbPortPicker.selectedPortNumber = selectedPort ? Number(selectedPort.port_number || 0) : null;

    $("bbPortStatus").textContent = `${ports.length} Port(s) geladen`;
    renderBbPortGrid();
    renderBbPortTable();
    renderBbPortDetail(selectedPort || ports[0] || null);
  } catch (error) {
    $("bbPortStatus").textContent = `Fehler: ${error.message}`;
    toast(`BB IN Port-Popup konnte nicht geladen werden: ${error.message}`, "error");
  }
}

async function loadMirrorForSelection() {
  const bbIn = state.install.selectedBbInPp;
  const port = state.install.selectedBbInPort;
  if (!bbIn || !port) {
    clearMirrorSelection();
    updateLookupButtons();
    return;
  }

  const ppId = Number(bbIn.id || bbIn.bb_in_pp_id || 0);
  const portValue = String(port.port_label || port.port_number || "").trim();
  if (!ppId || !portValue) {
    clearMirrorSelection();
    updateLookupButtons();
    return;
  }

  try {
    setMirrorStatus("BB OUT Mapping wird aufgeloest...");
    const url = new URL(API_BB_MIRROR, window.location.origin);
    url.searchParams.set("pp_id", String(ppId));
    url.searchParams.set("port", portValue);
    const data = await apiJson(url.toString());
    const out = data.bb_out || {};
    state.install.mirror = out;

    const outPpName = String(out.patchpanel_name || "").trim();
    const outPortLabel = String(out.port_label || out.port_number || "").trim();
    $("instBbOutPp").value = outPpName;
    $("instBbOutPort").value = outPortLabel;
    setMirrorStatus(`BB OUT auto: ${outPpName || "-"} ${outPortLabel || "-"}`);
  } catch (error) {
    clearMirrorSelection();
    throw error;
  } finally {
    updateLookupButtons();
  }
}

async function onBbPortClicked(port) {
  renderBbPortDetail(port);
  if (isPortUnavailable(port)) {
    toast("Port ist nicht verfuegbar", "error");
    return;
  }
  if (isPortOccupied(port)) {
    toast("Port ist belegt. Bitte freien Port waehlen.", "error");
    return;
  }

  state.install.selectedBbInPort = {
    port_label: String(port.port_label || "").trim(),
    port_number: parseNum(port.port_number || 0),
    status: String(port.status || ""),
    is_occupied: !!port.is_occupied,
  };
  state.install.bbPortPicker.selectedPortNumber = parseNum(port.port_number || 0);
  $("instBbInPort").value = state.install.selectedBbInPort.port_label || String(state.install.selectedBbInPort.port_number || "");
  renderBbPortGrid();
  renderBbPortTable();

  try {
    await loadMirrorForSelection();
    toast(`BB IN Port ${$("instBbInPort").value} gesetzt`, "success");
    closeBbPortPicker();
  } catch (error) {
    toast(`BB OUT Mapping fehlgeschlagen: ${error.message}`, "error");
  }
}

function updateLookupButtons() {
  const canEdit = canEditCurrentPlan();
  const deLine = state.lookups.de;
  const moveLine = state.lookups.move;
  const swap1 = state.lookups.swap1;
  const swap2 = state.lookups.swap2;
  const hasInstallCore = !!state.install.selectedRfra
    && !!state.install.selectedBbInPp
    && !!state.install.selectedBbInPort
    && !!state.install.mirror;
  const hasInstallZ = !!String($("instCustomer")?.value || "").trim()
    && !!String($("instRackCage")?.value || "").trim()
    && parseNum($("instPatchpanelId")?.value || 0) > 0
    && !!String($("instPort")?.value || "").trim();

  $("btnAddDe").disabled = !canEdit || !deLine;
  $("btnAddMove").disabled = !canEdit || !moveLine;
  $("btnAddSwap").disabled = !canEdit || !swap1 || !swap2 || Number(swap1.id) === Number(swap2.id);
  $("btnAddInstall").disabled = !canEdit || !hasInstallCore || !hasInstallZ;
  if ($("btnInstSelectBbInPort")) {
    $("btnInstSelectBbInPort").disabled = !canEdit || !state.install.selectedBbInPp;
  }

  if (swap1 && swap2 && Number(swap1.id) === Number(swap2.id)) {
    toast("Path Move: line1 und line2 muessen unterschiedlich sein", "error");
  }
}

function renderPlanInfo() {
  const planInfo = $("planInfo");
  const title = $("taskListTitle");
  const completeBtn = $("btnCompletePlan");
  const archiveBtn = $("btnArchivePlan");
  const readOnly = isPlanReadOnly(state.plan);

  if (!state.plan) {
    if (planInfo) planInfo.textContent = "Noch kein Plan - bitte KW speichern";
    if (title) title.textContent = "Tasks in KW";
    if (completeBtn) completeBtn.disabled = true;
    if (archiveBtn) archiveBtn.disabled = true;
    return;
  }

  const status = String(state.plan.status || "active");
  if (planInfo) {
    const mode = readOnly ? " | read-only" : "";
    planInfo.textContent = `KW ${state.plan.kw}/${state.plan.year} (ID ${state.plan.id}) | ${status}${mode}`;
  }
  if (title) title.textContent = `Tasks in KW ${state.plan.kw}/${state.plan.year}`;
  if (completeBtn) completeBtn.disabled = readOnly || !window.isAdminRole || !window.isAdminRole();
  if (archiveBtn) archiveBtn.disabled = !window.isAdminRole || !window.isAdminRole();
}

function updateCounters() {
  const done = state.tasks.filter((t) => String(t.status).toLowerCase() === "done").length;
  const cancelled = state.tasks.filter((t) => String(t.status).toLowerCase() === "cancelled").length;
  const pending = state.tasks.length - done - cancelled;
  $("statPending").textContent = String(Math.max(0, pending));
  $("statDone").textContent = String(done);
  $("statCancelled").textContent = String(cancelled);
}

function setPlanningFormEnabled() {
  const canEdit = canEditCurrentPlan();
  const formRoot = $("planningAccordion");
  if (formRoot) {
    formRoot.querySelectorAll("input, select, textarea, button").forEach((el) => {
      if (String(el.id || "").startsWith("btnLookup")) return;
      if (String(el.id || "") === "btnBack") return;
      if (el.hasAttribute("data-admin-only") || String(el.tagName).toLowerCase() !== "button") {
        el.disabled = !canEdit;
      }
    });
  }
  updateLookupButtons();
}

function renderTaskList() {
  const body = $("taskTableBody");
  const empty = $("tasksEmpty");
  if (!body || !empty) return;

  body.innerHTML = "";
  if (!state.tasks.length) {
    empty.style.display = "block";
  } else {
    empty.style.display = "none";
  }

  const canEdit = canEditCurrentPlan();

  for (const task of state.tasks) {
    const row = document.createElement("tr");
    row.className = "data-row";
    const serials = [
      task.payload?.serial,
      task.payload?.serial1,
      task.payload?.serial2,
      task.payload?.snapshot_before?.line1?.serial,
      task.payload?.snapshot_before?.line2?.serial,
    ].filter(Boolean);
    const uniqueSerials = [...new Set(serials.map((x) => String(x)))];
    const serialText = uniqueSerials.length ? uniqueSerials.join(" | ") : "-";

    const details = [];
    if (task.line_id) details.push(`line_id=${task.line_id}`);
    if (task.line1_id) details.push(`line1=${task.line1_id}`);
    if (task.line2_id) details.push(`line2=${task.line2_id}`);
    if (task.payload?.new_z_side?.customer_patchpanel_id) details.push(`newPP=${task.payload.new_z_side.customer_patchpanel_id}`);

    const actions = canEdit
      ? `
        <div class="row-actions">
          <button class="btn" data-action="edit" data-id="${task.id}" data-admin-only>Bearbeiten</button>
          <button class="btn" data-action="done" data-id="${task.id}" data-admin-only>Mark Done</button>
          <button class="btn btn-danger" data-action="remove" data-id="${task.id}" data-admin-only>Entfernen</button>
        </div>
      `
      : '<span class="small muted">read-only</span>';

    row.innerHTML = `
      <td>${taskTypeBadge(task.type)}</td>
      <td class="mono small">${escapeHtml(serialText)}</td>
      <td class="small">${escapeHtml(details.join(" | ") || "-")}</td>
      <td>${statusBadge(task.status)}</td>
      <td class="small">${escapeHtml(`KW ${state.plan?.kw || "-"}/${state.plan?.year || "-"}`)}</td>
      <td class="align-right">${actions}</td>
    `;
    body.appendChild(row);
  }

  if (canEdit) {
    body.querySelectorAll("[data-action='remove']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = Number(btn.dataset.id || 0);
        if (!id || !state.plan) return;
        if (!confirm(`Task #${id} wirklich entfernen?`)) return;
        try {
          await apiJson(`${API_PLANS}/${state.plan.id}/tasks/${id}`, { method: "DELETE" });
          toast("Task entfernt", "success");
          await reloadPlan();
        } catch (error) {
          toast(`Loeschen fehlgeschlagen: ${error.message}`, "error");
        }
      });
    });

    body.querySelectorAll("[data-action='done']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = Number(btn.dataset.id || 0);
        if (!id) return;
        const task = state.tasks.find((x) => Number(x.id) === id);
        try {
          const bodyPayload = { apply: true };
          if (String(task?.type || "").toLowerCase() === "install") {
            const serial = (prompt("Serial fuer Installation eingeben:") || "").trim();
            if (!serial) {
              toast("Serial ist fuer Installation erforderlich", "error");
              return;
            }
            bodyPayload.serial = serial;
          }
          await apiJson(`${API_TASKS}/${id}/done`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(bodyPayload),
          });
          toast("Task auf done gesetzt", "success");
          await reloadPlan();
        } catch (error) {
          toast(`Done fehlgeschlagen: ${error.message}`, "error");
        }
      });
    });

    body.querySelectorAll("[data-action='edit']").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = Number(btn.dataset.id || 0);
        if (!id || !state.plan) return;
        const current = state.tasks.find((x) => Number(x.id) === id);
        const next = prompt(`Neuer Status (${ALLOWED_STATUS.join(", ")})`, current?.status || "");
        if (!next) return;
        const status = next.trim().toLowerCase();
        if (!ALLOWED_STATUS.includes(status)) {
          toast("Ungueltiger Status", "error");
          return;
        }
        try {
          await apiJson(`${API_PLANS}/${state.plan.id}/tasks/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status }),
          });
          toast("Task aktualisiert", "success");
          await reloadPlan();
        } catch (error) {
          toast(`Update fehlgeschlagen: ${error.message}`, "error");
        }
      });
    });
  }

  updateCounters();
  setPlanningFormEnabled();
}

function renderArchiveList() {
  const body = $("archiveTableBody");
  const empty = $("archiveEmpty");
  if (!body || !empty) return;
  body.innerHTML = "";

  if (!state.archivePlans.length) {
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";

  for (const plan of state.archivePlans) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(`KW ${plan.kw}/${plan.year}`)}</td>
      <td>${statusBadge(plan.status)}</td>
      <td class="small">${escapeHtml(formatTs(plan.created_at))}</td>
      <td class="small">${escapeHtml(formatTs(plan.completed_at))}</td>
      <td class="small">${escapeHtml(formatTs(plan.archived_at))}</td>
      <td>${escapeHtml(String(plan.tasks_total ?? 0))}</td>
      <td class="align-right">
        <button class="btn" data-action="open-archive" data-id="${plan.id}">Oeffnen</button>
      </td>
    `;
    body.appendChild(tr);
  }

  body.querySelectorAll("[data-action='open-archive']").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const planId = Number(btn.dataset.id || 0);
      if (!planId) return;
      try {
        await loadPlanById(planId);
        switchTab("active");
        setPlanStatus("Archivplan geoeffnet (read-only)");
      } catch (error) {
        toast(`Archivplan konnte nicht geoeffnet werden: ${error.message}`, "error");
      }
    });
  });
}

function switchTab(tab) {
  state.activeTab = tab === "archive" ? "archive" : "active";
  const activeBtn = $("tabActive");
  const archiveBtn = $("tabArchive");
  const viewActive = $("viewActive");
  const viewArchive = $("viewArchive");

  if (activeBtn) {
    activeBtn.classList.toggle("btn-secondary", state.activeTab === "active");
  }
  if (archiveBtn) {
    archiveBtn.classList.toggle("btn-secondary", state.activeTab === "archive");
  }
  if (viewActive) viewActive.style.display = state.activeTab === "active" ? "block" : "none";
  if (viewArchive) viewArchive.style.display = state.activeTab === "archive" ? "block" : "none";
}

async function fetchPlans(params = {}) {
  const url = new URL(API_PLANS, window.location.origin);
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null || v === "") return;
    url.searchParams.set(k, String(v));
  });
  const data = await apiJson(url.toString());
  return Array.isArray(data.items) ? data.items : [];
}

async function loadArchivePlans() {
  setArchiveStatus("Archiv wird geladen...");
  try {
    state.archivePlans = await fetchPlans({ status: "completed,archived", limit: 500 });
    renderArchiveList();
    setArchiveStatus(`${state.archivePlans.length} Plan(e) im Archiv`);
  } catch (error) {
    setArchiveStatus(`Fehler: ${error.message}`);
    toast(`Archiv laden fehlgeschlagen: ${error.message}`, "error");
  }
}

async function loadPlanById(planId) {
  const data = await apiJson(`${API_PLANS}/${planId}`);
  state.plan = data.plan || null;
  state.tasks = Array.isArray(data.tasks) ? data.tasks : [];
  if (state.plan) {
    $("inputYear").value = String(state.plan.year);
    $("inputKw").value = String(state.plan.kw);
  }
  renderPlanInfo();
  renderTaskList();
}

async function loadSelectedWeekPlan() {
  const year = Number($("inputYear").value || 0);
  const kw = Number($("inputKw").value || 0);
  if (!year || !kw) {
    state.plan = null;
    state.tasks = [];
    renderPlanInfo();
    renderTaskList();
    return;
  }

  setPlanStatus("Pruefe Plan fuer ausgewaehlte KW...");
  try {
    const items = await fetchPlans({ year, kw, limit: 10 });
    if (!items.length) {
      state.plan = null;
      state.tasks = [];
      renderPlanInfo();
      renderTaskList();
      setPlanStatus("Noch kein Plan - bitte KW speichern.");
      return;
    }
    await loadPlanById(items[0].id);
    setPlanStatus("Plan geladen");
  } catch (error) {
    setPlanStatus(`Fehler: ${error.message}`);
    toast(`Plan laden fehlgeschlagen: ${error.message}`, "error");
  }
}

async function savePlan() {
  const year = Number($("inputYear").value || 0);
  const kw = Number($("inputKw").value || 0);
  if (!year || !kw || kw < 1 || kw > 53) {
    throw new Error("Bitte gueltiges Jahr und KW setzen");
  }

  const data = await apiJson(API_PLANS, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ year, kw }),
  });

  state.plan = data.plan || null;
  renderPlanInfo();
  setPlanStatus(data.created ? "Plan wurde neu erstellt" : "Plan fuer diese KW geladen");
  if (state.plan?.id) await loadPlanById(state.plan.id);
  return state.plan;
}

async function completeCurrentPlan() {
  if (!state.plan?.id) throw new Error("Bitte zuerst KW speichern");
  if (isPlanReadOnly(state.plan)) throw new Error("Plan ist bereits read-only");
  const ok = confirm("Wirklich abschliessen? Danach nur noch im Archiv (read-only).");
  if (!ok) return;
  await apiJson(`${API_PLANS}/${state.plan.id}/complete`, { method: "POST" });
  await loadPlanById(state.plan.id);
  await loadArchivePlans();
  switchTab("archive");
}

async function archiveCurrentPlan() {
  if (!state.plan?.id) throw new Error("Kein Plan geladen");
  const ok = confirm("Diesen Plan ins Archiv verschieben?");
  if (!ok) return;
  await apiJson(`${API_PLANS}/${state.plan.id}/archive`, { method: "POST" });
  await loadPlanById(state.plan.id);
  await loadArchivePlans();
  switchTab("archive");
}

function hasDuplicate(type, lineId, line2Id = null) {
  const activeTasks = state.tasks.filter((t) => String(t.status).toLowerCase() !== "cancelled");
  if (type === "path_move") {
    return activeTasks.some((t) => {
      if (String(t.type).toLowerCase() !== "path_move") return false;
      const ids = [Number(t.line1_id || 0), Number(t.line2_id || 0)];
      return ids.includes(Number(lineId)) || ids.includes(Number(line2Id));
    });
  }
  return activeTasks.some((t) => String(t.type).toLowerCase() === type && Number(t.line_id || 0) === Number(lineId));
}

async function addTask(taskPayload) {
  if (!state.plan?.id) throw new Error("Bitte zuerst KW speichern");
  const selectedYear = Number($("inputYear").value || 0);
  const selectedKw = Number($("inputKw").value || 0);
  if (Number(state.plan.year) !== selectedYear || Number(state.plan.kw) !== selectedKw) {
    throw new Error("Bitte erst die ausgewaehlte KW speichern/laden");
  }
  if (isPlanReadOnly(state.plan)) {
    throw new Error("Dieser Plan ist read-only");
  }

  const data = await apiJson(`${API_PLANS}/${state.plan.id}/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(taskPayload),
  });
  if (!data?.task?.id) throw new Error("Task konnte nicht erstellt werden");
  await loadPlanById(state.plan.id);
}

async function lookupSerial(serial) {
  const clean = String(serial || "").trim();
  if (!clean) return null;
  try {
    const data = await apiJson(`${API_LINES}/by-serial/${encodeURIComponent(clean)}`);
    return data.line || null;
  } catch {
    return null;
  }
}

async function lookupDeinstall() {
  const line = await lookupSerial($("deSerial").value);
  state.lookups.de = line;
  $("dePreview").innerHTML = line
    ? linePreviewHtml(line, "Deinstallation Preview")
    : '<div class="small" style="color:#fca5a5;">Serial nicht gefunden.</div>';
  updateLookupButtons();
}

async function lookupMove() {
  const line = await lookupSerial($("moveSerial").value);
  state.lookups.move = line;
  $("movePreview").innerHTML = line
    ? linePreviewHtml(line, "Line Move Preview")
    : '<div class="small" style="color:#fca5a5;">Serial nicht gefunden.</div>';
  updateLookupButtons();
}

async function lookupSwap() {
  const [line1, line2] = await Promise.all([
    lookupSerial($("swapSerial1").value),
    lookupSerial($("swapSerial2").value),
  ]);
  state.lookups.swap1 = line1;
  state.lookups.swap2 = line2;
  $("swapPreview1").innerHTML = line1
    ? linePreviewHtml(line1, "Line 1")
    : '<div class="small" style="color:#fca5a5;">Line 1 nicht gefunden.</div>';
  $("swapPreview2").innerHTML = line2
    ? linePreviewHtml(line2, "Line 2")
    : '<div class="small" style="color:#fca5a5;">Line 2 nicht gefunden.</div>';
  updateLookupButtons();
}

async function onAddInstall() {
  try {
    const rfra = state.install.selectedRfra;
    const bbIn = state.install.selectedBbInPp;
    const bbInPort = state.install.selectedBbInPort;
    const mirror = state.install.mirror;

    if (!rfra) throw new Error("Installation: RFRA Port auswaehlen");
    if (!bbIn) throw new Error("Installation: BB IN Patchpanel auswaehlen");
    if (!bbInPort) throw new Error("Installation: BB IN Port auswaehlen");
    if (!mirror) throw new Error("Installation: BB OUT Mapping fehlt");

    const bbInPpId = Number(bbIn.id || bbIn.bb_in_pp_id || 0);
    const bbInPortLabel = String(bbInPort.port_label || bbInPort.port_number || "").trim();
    if (!bbInPpId || !bbInPortLabel) {
      throw new Error("Installation: BB IN Auswahl ist unvollstaendig");
    }

    const portsData = await apiJson(`${API_PATCHPANELS}/${bbInPpId}/ports`);
    const ports = Array.isArray(portsData.ports) ? portsData.ports : [];
    const selectedPortNow = ports.find((p) => {
      const lbl = String(p.port_label || "").trim().toLowerCase();
      const num = String(p.port_number || "").trim().toLowerCase();
      const needle = bbInPortLabel.toLowerCase();
      return needle && (needle === lbl || needle === num);
    });
    if (!selectedPortNow) throw new Error("Installation: BB IN Port existiert nicht mehr");
    if (isPortUnavailable(selectedPortNow)) throw new Error("Installation: BB IN Port ist nicht verfuegbar");
    if (isPortOccupied(selectedPortNow)) throw new Error("Installation: BB IN Port ist bereits belegt");

    const customer = String($("instCustomer").value || "").trim();
    const rackCage = String($("instRackCage").value || "").trim();
    const customerPatchpanelId = Number($("instPatchpanelId").value || 0);
    const customerPort = String($("instPort").value || "").trim();
    const ru = String($("instRu").value || "").trim();

    if (!customer || !rackCage || !customerPatchpanelId || !customerPort) {
      throw new Error("Installation: Kunde, Rack/Cage, Patchpanel ID und Port sind Pflicht");
    }

    const switchName = String(rfra.switch_name || "").trim();
    const switchPort = String(rfra.switch_port || "").trim();
    const rfraName = String(rfra.rfra_name || `${switchName} ${switchPort}`).trim();
    const rfraRoom = String(rfra.room || $("instRfraRoom").value || "").trim();

    const aSidePpName = String(rfra.a_side_pp_name || rfra.a_side_pp_id || $("instASidePp").value || "").trim();
    const aSidePortLabel = String(rfra.a_side_port_label || $("instASidePort").value || "").trim();

    const bbInPpName = String(bbIn.bb_in_pp_name || bbIn.instance_id || "").trim();
    const bbInPortNumber = Number(selectedPortNow.port_number || bbInPort.port_number || 0) || null;

    const bbOutPpId = Number(mirror.patchpanel_id || 0) || null;
    const bbOutPpName = String(mirror.patchpanel_name || "").trim();
    const bbOutPortLabel = String(mirror.port_label || mirror.port_number || "").trim();
    const bbOutPortNumber = Number(mirror.port_number || 0) || null;

    if (!switchName || !switchPort) throw new Error("Installation: RFRA Mapping unvollstaendig");
    if (!aSidePpName || !aSidePortLabel) throw new Error("Installation: A-side Precable Mapping fehlt");
    if (!bbOutPpName || !bbOutPortLabel) throw new Error("Installation: BB OUT Mapping existiert nicht");

    const payload = {
      rfra_id: Number(rfra.rfra_id || rfra.id || 0),
      rfra_name: rfraName,
      rfra_room: rfraRoom,
      a_side_pp_id: String(rfra.a_side_pp_id || aSidePpName),
      a_side_pp_name: aSidePpName,
      a_side_port_label: aSidePortLabel,
      bb_in_pp_id: bbInPpId,
      bb_in_pp_name: bbInPpName,
      bb_in_port_number: bbInPortNumber,
      bb_in_port_label: bbInPortLabel,
      bb_out_pp_id: bbOutPpId,
      bb_out_pp_name: bbOutPpName,
      bb_out_port_number: bbOutPortNumber,
      bb_out_port_label: bbOutPortLabel,
      switch_name: switchName,
      switch_port: switchPort,
      a_patchpanel_id: aSidePpName,
      a_port_label: aSidePortLabel,
      bb_in_instance: bbInPpName,
      bb_in_port: bbInPortLabel,
      bb_out_instance: bbOutPpName,
      bb_out_port: bbOutPortLabel,
      customer,
      rack_cage: rackCage,
      customer_patchpanel_id: customerPatchpanelId,
      customer_port_label: customerPort,
      ru: ru || null,
    };
    await addTask({ type: "install", status: "pending_install", payload });
    toast("Installation zur KW hinzugefuegt", "success");
  } catch (error) {
    toast(`Installation fehlgeschlagen: ${error.message}`, "error");
  }
}

async function onAddDeinstall() {
  try {
    const line = state.lookups.de;
    if (!line) throw new Error("Serial existiert nicht");
    if (hasDuplicate("deinstall", line.id)) throw new Error("Duplicate: Leitung hat bereits Deinstallation in dieser KW");
    await addTask({
      type: "deinstall",
      status: "pending_deinstall",
      line_id: Number(line.id),
      payload: { serial: line.serial, snapshot: line },
    });
    toast("Deinstallation hinzugefuegt", "success");
  } catch (error) {
    toast(`Deinstallation fehlgeschlagen: ${error.message}`, "error");
  }
}

async function onAddMove() {
  try {
    const line = state.lookups.move;
    if (!line) throw new Error("Serial existiert nicht");
    if (hasDuplicate("move", line.id)) throw new Error("Duplicate: Leitung hat bereits Move in dieser KW");
    const newZ = {
      customer_patchpanel_id: Number($("movePatchpanelId").value || 0),
      customer_port_label: $("movePort").value.trim(),
      rack_code: $("moveRack").value.trim() || null,
      z_pp_number: $("moveZPpNumber").value.trim() || null,
    };
    if (!newZ.customer_patchpanel_id || !newZ.customer_port_label) {
      throw new Error("Move: neue Z-Seite Patchpanel ID und Port sind Pflicht");
    }
    await addTask({
      type: "move",
      status: "pending_move",
      line_id: Number(line.id),
      payload: { serial: line.serial, snapshot: line, new_z_side: newZ },
    });
    toast("Line Move hinzugefuegt", "success");
  } catch (error) {
    toast(`Move fehlgeschlagen: ${error.message}`, "error");
  }
}

async function onAddSwap() {
  try {
    const line1 = state.lookups.swap1;
    const line2 = state.lookups.swap2;
    if (!line1 || !line2) throw new Error("Beide Serials muessen existieren");
    if (Number(line1.id) === Number(line2.id)) throw new Error("line1 und line2 duerfen nicht gleich sein");
    if (hasDuplicate("path_move", line1.id, line2.id)) {
      throw new Error("Duplicate: eine der Leitungen hat bereits path_move in dieser KW");
    }
    await addTask({
      type: "path_move",
      status: "pending_path_move",
      line1_id: Number(line1.id),
      line2_id: Number(line2.id),
      payload: { serial1: line1.serial, serial2: line2.serial, snapshot_before: { line1, line2 } },
    });
    toast("Path Move hinzugefuegt", "success");
  } catch (error) {
    toast(`Path Move fehlgeschlagen: ${error.message}`, "error");
  }
}

function debounceLookup(key, fn) {
  if (state.lookupDebounce[key]) clearTimeout(state.lookupDebounce[key]);
  state.lookupDebounce[key] = setTimeout(fn, 450);
}

function bindAccordion() {
  const items = document.querySelectorAll("#planningAccordion .accordion-item");
  items.forEach((item) => {
    const header = item.querySelector(".accordion-header");
    if (!header) return;
    header.addEventListener("click", () => {
      const open = item.getAttribute("data-open") === "true";
      item.setAttribute("data-open", open ? "false" : "true");
    });
  });
}

function bindHandlers() {
  $("btnBack")?.addEventListener("click", () => {
    window.location.href = "cross-connects.html";
  });

  $("btnSavePlan")?.addEventListener("click", async () => {
    try {
      setPlanStatus("Plan wird gespeichert...");
      await savePlan();
      await loadArchivePlans();
      toast("KW gespeichert", "success");
    } catch (error) {
      setPlanStatus(`Fehler: ${error.message}`);
      toast(`KW speichern fehlgeschlagen: ${error.message}`, "error");
    }
  });

  $("btnCompletePlan")?.addEventListener("click", async () => {
    try {
      await completeCurrentPlan();
      toast("KW abgeschlossen", "success");
    } catch (error) {
      toast(`KW abschliessen fehlgeschlagen: ${error.message}`, "error");
    }
  });

  $("btnArchivePlan")?.addEventListener("click", async () => {
    try {
      await archiveCurrentPlan();
      toast("Plan archiviert", "success");
    } catch (error) {
      toast(`Archivieren fehlgeschlagen: ${error.message}`, "error");
    }
  });

  $("tabActive")?.addEventListener("click", () => switchTab("active"));
  $("tabArchive")?.addEventListener("click", async () => {
    switchTab("archive");
    await loadArchivePlans();
  });

  $("inputYear")?.addEventListener("change", loadSelectedWeekPlan);
  $("inputKw")?.addEventListener("change", loadSelectedWeekPlan);

  $("btnLookupDe")?.addEventListener("click", lookupDeinstall);
  $("btnLookupMove")?.addEventListener("click", lookupMove);
  $("btnLookupSwap")?.addEventListener("click", lookupSwap);
  $("deSerial")?.addEventListener("input", () => debounceLookup("de", lookupDeinstall));
  $("moveSerial")?.addEventListener("input", () => debounceLookup("move", lookupMove));
  $("instRfraQuery")?.addEventListener("input", () => debounceLookup("rfra", searchRfraOptions));
  $("instRfraSelect")?.addEventListener("change", onRfraSelected);
  $("instBbInPp")?.addEventListener("change", onBbInPatchpanelChanged);
  $("btnInstSelectBbInPort")?.addEventListener("click", openBbPortPicker);
  $("bbPortClose")?.addEventListener("click", closeBbPortPicker);
  $("bbPortBackdrop")?.addEventListener("click", (ev) => {
    if (ev.target && ev.target.id === "bbPortBackdrop") closeBbPortPicker();
  });

  ["instCustomer", "instRackCage", "instPatchpanelId", "instPort"].forEach((id) => {
    $(id)?.addEventListener("input", updateLookupButtons);
    $(id)?.addEventListener("change", updateLookupButtons);
  });

  $("btnAddInstall")?.addEventListener("click", onAddInstall);
  $("btnAddDe")?.addEventListener("click", onAddDeinstall);
  $("btnAddMove")?.addEventListener("click", onAddMove);
  $("btnAddSwap")?.addEventListener("click", onAddSwap);
}

async function init() {
  const iso = getIsoWeek(new Date());
  $("inputYear").value = String(iso.year);
  $("inputKw").value = String(iso.week);

  bindAccordion();
  bindHandlers();
  switchTab("active");
  updateLookupButtons();

  try {
    await searchRfraOptions();
    await loadSelectedWeekPlan();
    await loadArchivePlans();
  } catch (error) {
    setPlanStatus(`Fehler: ${error.message}`);
    toast(`Initiales Laden fehlgeschlagen: ${error.message}`, "error");
  }
}

document.addEventListener("DOMContentLoaded", init);
