// migration-audit.js
// - Upload XLSB -> import into migration_audit_lines
// - List audit lines
// - Edit BB IN/OUT via cassette port grid (NO dropdown)
// - Approve -> create active cross-connect

// Use the same config as the rest of the app (see config.js)
// window.API_ROOT = <origin>/api/v1
const API = String(window.API_ROOT || "").replace(/\/+$/, "");

function currentRole() {
  return String(
    localStorage.getItem("userRole") || sessionStorage.getItem("userRole") || "viewer"
  ).toLowerCase();
}

function isAdminRole() {
  const r = currentRole();
  return r === "admin" || r === "superadmin";
}


// --- A-side auto-resolve (RFRA switch/port -> A PP + A Port) via pre_cabled_links ---
let _resolveASideTimer = null;
async function resolveASideNow() {
  const sw = (el("inpSwitchName").value || "").trim();
  const sp = (el("inpSwitchPort").value || "").trim();
  if (!sw || !sp) return;

  try {
    const r = await apiJson(`${API}/migration-audit/resolve-a-side?switch_name=${encodeURIComponent(sw)}&switch_port=${encodeURIComponent(sp)}`);
    if (r && r.found) {
      // Only overwrite if empty OR user hasn't manually changed it from Excel.
      if (!el("inpAPP").value) el("inpAPP").value = r.a_pp_number || "";
      if (!el("inpAPort").value) el("inpAPort").value = r.a_port_label || "";
    }
  } catch (e) {
    // ignore (mapping may not exist)
  }
}

function scheduleResolveASide() {
  clearTimeout(_resolveASideTimer);
  _resolveASideTimer = setTimeout(resolveASideNow, 250);
}

function installResolveASideListeners() {
  const sw = el("inpSwitchName");
  const sp = el("inpSwitchPort");
  if (!sw || !sp) return;
  if (sw.dataset.boundResolve === "1") return;
  sw.dataset.boundResolve = "1";
  sp.dataset.boundResolve = "1";
  sw.addEventListener("input", scheduleResolveASide);
  sp.addEventListener("input", scheduleResolveASide);
}


const letters = ["A","B","C","D"];
const positions = [1,2,3,4,5,6];

const el = (id) => document.getElementById(id);

let currentStatus = "imported";
let currentItems = [];
let allItems = [];
const auditFilters = { room:'', switch:'', bb_out_pp:'', serial:'' };
let _filterCol = '';
let _filterModal = null;

let editId = null;
let bbInCtx = null;
let bbInPorts = [];
let selectedPanel = null; // {id, instance_id}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(msg) {
  const box = el("importMsg");
  if (box) box.textContent = msg;
}

async function apiJson(url, opts) {
  const res = await fetch(url, opts);
  let data = null;
  try { data = await res.json(); } catch { /* ignore */ }
  if (!res.ok) {
    const d = (data && (data.detail || data.message)) ? (data.detail || data.message) : (res.statusText || "Error");
    throw new Error(d);
  }
  return data;
}

function renderPortGrid(container, ports, onPick, opts = {}) {
  container.innerHTML = "";
  const map = new Map();
  (ports || []).forEach(p => map.set(p.label, p));

  let maxRowNum = 0;
  for (const label of map.keys()) {
    const m = String(label).match(/^(\d+)[A-D]\d+$/);
    if (m) maxRowNum = Math.max(maxRowNum, Number(m[1]));
  }
  if (!maxRowNum) maxRowNum = 4;

  for (let rowNum = 1; rowNum <= maxRowNum; rowNum++) {
    const row = document.createElement("div");
    row.className = "cassette-row";

    for (const letter of letters) {
      const card = document.createElement("div");
      card.className = "cassette";

      const title = document.createElement("h4");
      title.textContent = `Kassette ${rowNum}${letter}`;
      card.appendChild(title);

      const portsWrap = document.createElement("div");
      portsWrap.className = "ports";

      for (const pos of positions) {
        const label = `${rowNum}${letter}${pos}`;
        const p = map.get(label);
        const btn = document.createElement("button");
        btn.className = "pbtn";
        btn.textContent = label;

        if (!p) {
          btn.classList.add("na");
          btn.disabled = true;
          portsWrap.appendChild(btn);
          continue;
        }

        // Room filter (customer room prefixes)
        if (opts.roomPrefixes && opts.roomPrefixes.length && p.peer_instance_id) {
          const ok = opts.roomPrefixes.some(pref => String(p.peer_instance_id).startsWith(String(pref)));
          if (!ok) {
            btn.classList.add("na");
            btn.disabled = true;
            portsWrap.appendChild(btn);
            continue;
          }
        }

        if (p.occupied) {
          btn.classList.add("occ");
          btn.disabled = true;
        } else if (p.selectable === false) {
          btn.classList.add("na");
          btn.disabled = true;
        } else {
          btn.classList.add("free");
          btn.disabled = false;
        }

        if (opts.selected && label === opts.selected) {
          btn.classList.add("sel");
          btn.classList.add("occ");
        }

        if (!btn.disabled) {
          btn.addEventListener("click", () => onPick(label));
        }
        portsWrap.appendChild(btn);
      }

      card.appendChild(portsWrap);
      row.appendChild(card);
    }

    container.appendChild(row);
  }
}

async function loadList() {
  const data = await apiJson(`${API}/migration-audit/list?status=${encodeURIComponent(currentStatus)}`);
  allItems = data.items || [];
  currentItems = _applyFilters(allItems);
  _updateFilterBadges();
  renderTable();
  _wireFilterUI();
  _wireFilterUI();
}


function _getFilterVal(it, col) {
  if (!it) return '';
  if (col === 'room') return String(it.room || '').trim();
  if (col === 'switch') return String(it.switch_name || '').trim();
  if (col === 'bb_out_pp') return String((it.backbone_out_instance_id || it.pp2_raw || it.pp2_number || '')).trim();
  if (col === 'serial') return String(it.serial_number || '').trim();
  return '';
}

function _applyFilters(items) {
  return (items || []).filter(it => {
    for (const [col, val] of Object.entries(auditFilters)) {
      if (!val) continue;
      if (_getFilterVal(it, col) !== val) return false;
    }
    return true;
  });
}

function _updateFilterBadges() {
  document.querySelectorAll('.audit-filter-badge').forEach(b => {
    const col = b.getAttribute('data-col');
    const v = auditFilters[col] || '';
    if (v) { b.textContent = v; b.classList.remove('d-none'); }
    else { b.textContent = ''; b.classList.add('d-none'); }
  });
}

function _ensureFilterModal() {
  if (_filterModal) return;
  const el = document.getElementById('filterModal');
  if (!el) return;
  _filterModal = new bootstrap.Modal(el);
}

function openFilter(col) {
  _filterCol = col;
  _ensureFilterModal();
  if (!_filterModal) return;

  const titleMap = { room:'A ROOM', switch:'Switch', bb_out_pp:'BB OUT PP', serial:'Serial' };
  document.getElementById('filterModalTitle').textContent = 'Filter: ' + (titleMap[col] || col);

  const select = document.getElementById('filterModalSelect');
  const search = document.getElementById('filterModalSearch');
  const hint = document.getElementById('filterModalHint');

  const values = Array.from(new Set((allItems || []).map(it => _getFilterVal(it, col)).filter(v => v))).sort((a,b)=>a.localeCompare(b));
  const current = auditFilters[col] || '';

  function renderOptions(q='') {
    const qq = String(q || '').trim().toLowerCase();
    select.innerHTML = '';
    const filtered = values.filter(v => !qq || v.toLowerCase().includes(qq));
    for (const v of filtered) {
      const opt = document.createElement('option');
      opt.value = v;
      opt.textContent = v;
      if (v === current) opt.selected = true;
      select.appendChild(opt);
    }
    hint.textContent = filtered.length + ' Werte';
  }

  search.value = '';
  renderOptions('');
  search.oninput = () => renderOptions(search.value);

  _filterModal.show();
}

function _wireFilterUI() {
  // buttons in header
  document.querySelectorAll('.audit-filter-btn').forEach(btn => {
    if (btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openFilter(btn.getAttribute('data-col'));
    });
  });

  const applyBtn = document.getElementById('filterModalApply');
  const clearBtn = document.getElementById('filterModalClear');
  if (applyBtn && applyBtn.dataset.bound !== '1') {
    applyBtn.dataset.bound = '1';
    applyBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const sel = document.getElementById('filterModalSelect');
      auditFilters[_filterCol] = (sel && sel.value) ? sel.value : '';
      currentItems = _applyFilters(allItems);
      _updateFilterBadges();
      renderTable();
  _wireFilterUI();
      _filterModal.hide();
    });
  }
  if (clearBtn && clearBtn.dataset.bound !== '1') {
    clearBtn.dataset.bound = '1';
    clearBtn.addEventListener('click', (e) => {
      e.preventDefault();
      auditFilters[_filterCol] = '';
      currentItems = _applyFilters(allItems);
      _updateFilterBadges();
      renderTable();
  _wireFilterUI();
      _filterModal.hide();
    });
  }
}

function renderTable() {
  const tbody = el("auditTable").querySelector("tbody");
  tbody.innerHTML = "";
  if (!currentItems.length) {
    tbody.innerHTML = `<tr><td colspan="16" class="text-muted">Keine Einträge.</td></tr>`;
    return;
  }

  const isAdmin = isAdminRole();
  for (const it of currentItems) {
    const tr = document.createElement("tr");
    const conf = (it.conflicts || []).join("; ");
    const ready = !!it.ready;
    const fmtPP = (raw, fallback) => {
      const r = (raw || "").toString().trim();
      if (r) return r;
      return (fallback || "").toString().trim();
    };

    tr.innerHTML = `
      <td>${it.id}</td>
      <td>${escapeHtml(it.room || "")}</td>
      <td>
        ${escapeHtml(it.switch_name || "")}<div class="text-muted" style="font-size:.8rem;">${escapeHtml(it.switch_port || "")}</div>
        ${it.logical_name ? `<div class="text-muted" style="font-size:.75rem;">LOGICAL: ${escapeHtml(it.logical_name)}</div>` : ``}
      </td>

      <td>${escapeHtml(fmtPP(it.a_pp_number, it.a_pp_raw))}</td>
      <td>${escapeHtml(it.a_port_label || "")}${it.a_eqx_port ? (' <span class="text-muted">/ ' + escapeHtml(it.a_eqx_port) + '</span>') : ''}</td>

      <td>${escapeHtml((it.backbone_in_instance_id || it.pp1_raw || it.pp1_number || ""))}</td>
      <td>${escapeHtml(it.backbone_in_port_label || it.pp1_port_label || "")}</td>

      <td>${escapeHtml((it.backbone_out_instance_id || it.pp2_raw || it.pp2_number || ""))}</td>
      <td>${escapeHtml(it.backbone_out_port_label || it.pp2_port_label || "")}</td>

      <td>${escapeHtml(it.rack_code || "")}</td>

      <td>${escapeHtml(fmtPP(it.z_pp_number, it.z_pp_raw))}</td>
      <td>${escapeHtml(it.z_port_label || "")}</td>

      <td>${escapeHtml(it.product_id || "")}</td>
      <td>${escapeHtml(it.serial_number || "")}</td>

      <td>${conf ? `<span class="badge badge-danger">${escapeHtml(conf)}</span>` : ((!it.backbone_in_instance_id || !it.backbone_out_instance_id) ? `<span class="badge badge-warning">Pick BB</span>` : ``)}</td>
      <td class="text-end actions">
        ${isAdmin ? (
          currentStatus === "imported" ? `
            <button class="btn btn-sm btn-outline-primary me-1" data-action="edit" data-id="${it.id}" data-admin-only>Audit</button>
          ` : (currentStatus === "audited" ? `
            <button class="btn btn-sm btn-outline-secondary me-1" data-action="edit" data-id="${it.id}" data-admin-only>Bearbeiten</button>
          ` : ``)
        ) : `<span class=\"text-muted small\">read-only</span>`}
      </td>

    `;
    tbody.appendChild(tr);
  }

  if (isAdmin) {
    tbody.querySelectorAll("button[data-action='edit']").forEach(btn => {
      btn.addEventListener("click", () => openEdit(Number(btn.dataset.id)));
    });
    tbody.querySelectorAll("button[data-action='audit']").forEach(btn => {
      btn.addEventListener("click", () => approve(Number(btn.dataset.id)));
    });
  }
}

async function importXlsb() {
  if (!isAdminRole()) {
    toast("Nur Admin darf importieren.");
    return;
  }
  const f = el("auditFile").files && el("auditFile").files[0];
  if (!f) { toast("Bitte XLSB auswählen."); return; }
  toast("Import läuft…");
  const fd = new FormData();
  fd.append("file", f);
  try {
    const data = await apiJson(`${API}/migration-audit/import`, { method: "POST", body: fd });
    toast(`Import ok: inserted=${data.inserted}, skipped=${data.skipped}`);
    await loadList();
  } catch (e) {
    toast(`Import Fehler: ${e.message}`);
  }
}

async function openEdit(id) {
  if (!isAdminRole()) {
    toast("Nur Admin darf bearbeiten.");
    return;
  }
  installResolveASideListeners();
  editId = id;
  const item = currentItems.find(x => x.id === id);
  if (!item) return;

  // Editable A/Z + switch fields
  el("inpSwitchName").value = item.switch_name || "";
  el("inpSwitchPort").value = item.switch_port || "";
  scheduleResolveASide();
  el("inpAPP").value = item.a_pp_number || item.a_pp_raw || "";
  el("inpAPort").value = item.a_port_label || "";
  el("inpZPP").value = item.z_pp_number || item.z_pp_raw || "";
  el("inpZPort").value = item.z_port_label || "";
  el("inpProductId").value = item.product_id || "";
  el("inpSerial").value = item.serial_number || "";
  el("auditComment").value = item.tech_comment || "";
  el("bbInInst").textContent = item.backbone_in_instance_id || "—";
  el("bbInPort").textContent = item.backbone_in_port_label || "—";
  el("bbOutInst").textContent = item.backbone_out_instance_id || "—";
  el("bbOutPort").textContent = item.backbone_out_port_label || "—";

  selectedPanel = null;
  bbInPorts = [];
  el("bbInGrid").innerHTML = "<div class='text-muted'>Lade…</div>";
  el("bbInPanelList").innerHTML = "";

  const data = await apiJson(`${API}/migration-audit/${id}/bbin-pps`);
  bbInCtx = data.context || null;
  const pps = data.patchpanels || [];
  if (!pps.length) {
    el("bbInPanelList").innerHTML = `<div class="text-muted">Keine passenden Backbone Panels gefunden.</div>`;
    el("bbInGrid").innerHTML = `<div class="text-muted">—</div>`;
  } else {
    const list = el("bbInPanelList");
    list.innerHTML = "";
    for (const pp of pps) {
      const a = document.createElement("button");
      a.type = "button";
      a.className = "list-group-item list-group-item-action";
      a.innerHTML = `<div class="fw-semibold">${escapeHtml(pp.instance_id || ("PP #"+pp.id))}</div>
        <div class="text-muted" style="font-size:.8rem;">Ports → ${escapeHtml(bbInCtx && bbInCtx.room ? bbInCtx.room : "")}</div>`;
      a.addEventListener("click", () => selectPanel(pp, item));
      list.appendChild(a);
    }

    // Auto-select panel from Excel (if present)
    // Excel may contain "BB IN PP" in the form "M5.04S6/1 -> M4.5".
    // The patchpanel instance_id in DB is only the left part.
    const want = String(item.backbone_in_instance_id || "").split("->", 1)[0].trim();
    if (want) {
      const found = pps.find(x => String(x.instance_id || "").trim() === want);
      if (found) {
        // select after buttons exist
        setTimeout(() => selectPanel(found, item), 0);
      }
    }
  }

  const modal = new bootstrap.Modal(el("editModal"));
  modal.show();
}

async function selectPanel(pp, item) {
  selectedPanel = pp;
  // highlight selection
  el("bbInPanelList").querySelectorAll(".list-group-item").forEach(x => x.classList.remove("active"));
  const btns = Array.from(el("bbInPanelList").querySelectorAll("button"));
  const idx = btns.findIndex(b => b.textContent.includes(pp.instance_id));
  if (idx >= 0) btns[idx].classList.add("active");

  await loadPorts(pp, item);
}

async function loadPorts(pp, item) {
  el("bbInGrid").innerHTML = "<div class='text-muted'>Ports lade…</div>";
  const res = await apiJson(`${API}/patchpanels/${pp.id}/ports`);
  const roomPrefixes = (bbInCtx && Array.isArray(bbInCtx.prefixes) && bbInCtx.prefixes.length)
    ? bbInCtx.prefixes.map(String)
    : ((bbInCtx && bbInCtx.room_norm) ? [String(bbInCtx.room_norm)] : []);
  const selectedLabel = String(item.backbone_in_port_label || "").trim();
  const bbInInstanceId = String(pp.instance_id || "").trim();

  // ports normalize
  bbInPorts = (res.ports || []).map(p => {
    const label = (p.port_label || p.label || "").trim();
    const peerInst = (p.peer_instance_id || (p.peer && p.peer.instance_id) || "").toString().trim();
    const peerPort = (p.peer_port_label || (p.peer && p.peer.port_label) || "").toString().trim();
    const st = (p.status || "").toString().trim().toLowerCase();
    // IMPORTANT: connected_to can contain pre-cabling info and must NOT mark a port as occupied.
    let occupied = (typeof p.occupied === "boolean") ? p.occupied : (st === "occupied" || st === "used" || st === "busy");
    const selectable = (typeof p.selectable === "boolean") ? p.selectable : !occupied;
    return { label, peer_instance_id: peerInst || null, peer_port_label: peerPort || null, occupied, selectable };
  }).filter(p => p.label);

  const pick = (label) => {
    const po = bbInPorts.find(x => x.label === label);
    if (!po) return;
    if (roomPrefixes.length && po.peer_instance_id) {
      const ok = roomPrefixes.some(pref => String(po.peer_instance_id).startsWith(pref));
      if (!ok) return;
    }
    if (po.occupied) return;
    // update display fields (BB OUT derived)
    el("bbInInst").textContent = bbInInstanceId;
    el("bbInPort").textContent = label;
    el("bbOutInst").textContent = po.peer_instance_id || "";
    el("bbOutPort").textContent = po.peer_port_label || "";
    // store in item for later save
    item.backbone_in_instance_id = bbInInstanceId;
    item.backbone_in_port_label = label;
    item.backbone_out_instance_id = po.peer_instance_id || "";
    item.backbone_out_port_label = po.peer_port_label || "";
    renderPortGrid(el("bbInGrid"), bbInPorts, pick, { selected: label, roomPrefixes });
  };

  renderPortGrid(el("bbInGrid"), bbInPorts, pick, { selected: selectedLabel, roomPrefixes });

  // If the audit line already has a BB IN port (from Excel or prior edits),
  // auto-derive BB OUT from the selected port's peer mapping so the modal
  // doesn't show stale/wrong BB OUT values.
  if (selectedLabel) {
    const po = bbInPorts.find(x => x.label === selectedLabel);
    const okRoom = (!roomPrefixes.length || !po.peer_instance_id || roomPrefixes.some(pref => String(po.peer_instance_id).startsWith(pref)));
    if (po && !po.occupied && okRoom) {
      // Re-use the same handler to keep UI+item state consistent.
      pick(selectedLabel);
    }
  }
  // also update displayed instance even before pick
  el("bbInInst").textContent = bbInInstanceId || "—";
}

async function saveAudit() {
  if (!isAdminRole()) {
    toast("Nur Admin darf speichern.");
    return;
  }
  if (!editId) return;
  const item = currentItems.find(x => x.id === editId);
  if (!item) return;
  try {
    // 1) Persist edits on the audit row
    await apiJson(`${API}/migration-audit/${editId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        switch_name: el("inpSwitchName").value || null,
        switch_port: el("inpSwitchPort").value || null,
        a_pp_number: el("inpAPP").value || null,
        a_port_label: el("inpAPort").value || null,
        z_pp_number: el("inpZPP").value || null,
        z_port_label: el("inpZPort").value || null,
        product_id: el("inpProductId").value || null,
        serial_number: el("inpSerial").value || null,
        backbone_in_instance_id: item.backbone_in_instance_id || null,
        backbone_in_port_label: item.backbone_in_port_label || null,
        backbone_out_instance_id: item.backbone_out_instance_id || null,
        backbone_out_port_label: item.backbone_out_port_label || null,
        tech_comment: el("auditComment").value || null,
      })
    });

    // 2) Finalize (move to Audited and create cross_connect)
    const username = localStorage.getItem('username') || sessionStorage.getItem('username') || 'unknown';
    await apiJson(`${API}/migration-audit/${editId}/audited`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current_user: username })
    });

    toast("Audit übernommen.");
    // Reload both states by switching to audited tab automatically
    currentStatus = "audited";
    document.querySelectorAll("#tabs button").forEach(b => b.classList.remove("active"));
    const tab = document.querySelector('#tabs button[data-status="audited"]');
    if (tab) tab.classList.add("active");
    await loadList();
    // close modal
    const m = bootstrap.Modal.getInstance(el("editModal"));
    if (m) m.hide();
  } catch (e) {
    toast(`Save Fehler: ${e.message}`);
  }
}

async function approve(id) {
  if (!isAdminRole()) {
    toast("Nur Admin darf freigeben.");
    return;
  }
  const username = localStorage.getItem('username') || sessionStorage.getItem('username') || 'unknown';
  if (!confirm(`Audit übernehmen? (#${id})`)) return;
  try {
    await apiJson(`${API}/migration-audit/${id}/audited`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current_user: username })
    });
    toast(`Übernommen: #${id}`);
    await loadList();
  } catch (e) {
    toast(`Übernahme Fehler: ${e.message}`);
  }
}

function bindTabs() {
  document.querySelectorAll("#tabs button[data-status]").forEach(btn => {
    btn.addEventListener("click", async () => {
      document.querySelectorAll("#tabs button").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentStatus = btn.dataset.status;
      await loadList();
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  bindTabs();
  el("btnImport").addEventListener("click", importXlsb);
  el("btnReload").addEventListener("click", () => loadList());
  el("btnSaveAudit").addEventListener("click", saveAudit);
  loadList().catch(err => toast(err.message));
});
