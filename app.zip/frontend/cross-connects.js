const API = String(window.API_CROSSCONNECTS || "").replace(/\/+$/, "");
const API_PATCHPANELS = String(window.API_PATCHPANELS || "").replace(/\/+$/, "");

const state = {
  items: [],
  total: 0,
  loading: false,
  modalMode: null,
  modalItem: null,
  zPortPicker: {
    panelId: null,
    panelMeta: null,
    ports: [],
    selectedPortNumber: null,
    allowOverride: false,
  },
};

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function showToast(message, type = "info") {
  const wrap = $("toastWrap");
  if (!wrap) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  wrap.appendChild(el);
  setTimeout(() => {
    el.remove();
  }, 3400);
}

function statusBadge(status) {
  const s = String(status || "").toLowerCase();
  let cls = "badge-neutral";
  if (s === "active" || s === "done") cls = "badge-success";
  else if (s.includes("pending") || s === "planned" || s === "review" || s === "in_progress") cls = "badge-warning";
  else if (s === "deinstalled" || s === "cancelled") cls = "badge-danger";
  return `<span class="badge ${cls}">${escapeHtml(status || "-")}</span>`;
}

function setListStatus(text, loading = false) {
  const box = $("listStatus");
  if (!box) return;
  if (!text) {
    box.textContent = "";
    return;
  }
  box.innerHTML = loading
    ? `<span class="spinner"></span><span>${escapeHtml(text)}</span>`
    : `<span>${escapeHtml(text)}</span>`;
}

function renderSkeletonRows() {
  const body = $("ccTableBody");
  const empty = $("emptyState");
  if (!body) return;
  if (empty) empty.hidden = true;
  body.innerHTML = "";
  for (let i = 0; i < 6; i += 1) {
    const tr = document.createElement("tr");
    tr.className = "skeleton-row";
    tr.innerHTML = `<td colspan="6"><div class="skeleton-line"></div></td>`;
    body.appendChild(tr);
  }
}

function customerText(item) {
  return item.system_name || item.customer_name || item.rack_code || "-";
}

function aSideHtml(item) {
  const inInstance = item.backbone_in_instance_id || "-";
  const inPort = item.backbone_in_port_label || "-";
  const outInstance = item.backbone_out_instance_id || "-";
  const outPort = item.backbone_out_port_label || "-";
  return `BB IN: ${escapeHtml(inInstance)} ${escapeHtml(inPort)}<br>BB OUT: ${escapeHtml(outInstance)} ${escapeHtml(outPort)}`;
}

function zSideText(item) {
  return `${item.rack_code || "-"} ${item.z_pp_number || item.customer_patchpanel_id || "-"} ${item.customer_port_label || "-"}`;
}

function renderRows() {
  const body = $("ccTableBody");
  const empty = $("emptyState");
  if (!body) return;

  body.innerHTML = "";

  if (!state.items.length) {
    if (empty) {
      empty.hidden = false;
      empty.textContent = "Keine Cross Connects fuer den aktuellen Filter.";
    }
    return;
  }

  if (empty) empty.hidden = true;

  for (const item of state.items) {
    const tr = document.createElement("tr");
    tr.className = "data-row";
    tr.innerHTML = `
      <td>
        <a href="#" class="mono" data-action="details" data-id="${item.id}">${escapeHtml(item.serial || "-")}</a>
      </td>
      <td>${escapeHtml(customerText(item))}</td>
      <td class="small">${aSideHtml(item)}</td>
      <td class="small">${escapeHtml(zSideText(item))}</td>
      <td>${statusBadge(item.status)}</td>
      <td class="row-actions align-right">
        <button class="btn" data-action="details" data-id="${item.id}">Details</button>
        <button class="btn" data-action="edit" data-id="${item.id}" data-admin-only>Bearbeiten</button>
      </td>
    `;
    body.appendChild(tr);
  }

  if (window.getCurrentRole && !window.isAdminRole()) {
    document.querySelectorAll("#ccTableBody [data-admin-only]").forEach((el) => {
      el.style.display = "none";
    });
  }
}

function updateStats() {
  const shown = $("statShown");
  const total = $("statTotal");
  const filter = $("statFilter");
  if (shown) shown.textContent = String(state.items.length || 0);
  if (total) total.textContent = String(state.total || 0);
  if (filter) filter.textContent = $("statusFilter")?.value || "all";
}

function buildQuery() {
  const status = $("statusFilter")?.value || "all";
  const search = ($("searchInput")?.value || "").trim();
  const customer = ($("customerFilter")?.value || "").trim();
  const q = `${search} ${customer}`.trim();

  const url = new URL(`${API}/list`);
  url.searchParams.set("status", status);
  url.searchParams.set("limit", "200");
  url.searchParams.set("offset", "0");
  if (q) url.searchParams.set("q", q);
  return url.toString();
}

async function loadList() {
  state.loading = true;
  renderSkeletonRows();
  setListStatus("Cross Connects werden geladen...", true);

  try {
    const res = await fetch(buildQuery());
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);

    state.items = Array.isArray(data.items) ? data.items : [];
    state.total = Number(data.total || 0);
    renderRows();
    updateStats();
    setListStatus(`Geladen: ${state.items.length} von ${state.total}`);
  } catch (error) {
    state.items = [];
    state.total = 0;
    renderRows();
    updateStats();
    setListStatus(`Fehler: ${error.message}`);
    showToast(`Fehler beim Laden: ${error.message}`, "error");
  } finally {
    state.loading = false;
  }
}

function modalField(label, key, value, options = {}) {
  const readOnly = options.readOnly ? "readonly" : "";
  const disabled = options.disabled ? "disabled" : "";
  const type = options.type || "text";
  const cls = options.span2 ? "field span-2" : "field";

  if (options.select && Array.isArray(options.select)) {
    const opts = options.select
      .map((opt) => `<option value="${escapeHtml(opt)}" ${String(value || "") === String(opt) ? "selected" : ""}>${escapeHtml(opt)}</option>`)
      .join("");
    return `
      <div class="${cls}">
        <label class="small muted">${escapeHtml(label)}</label>
        <select class="select" data-field="${escapeHtml(key)}" ${disabled}>${opts}</select>
      </div>
    `;
  }

  return `
    <div class="${cls}">
      <label class="small muted">${escapeHtml(label)}</label>
      <input class="input" type="${type}" data-field="${escapeHtml(key)}" value="${escapeHtml(value ?? "")}" ${readOnly} ${disabled} />
    </div>
  `;
}

function isAdminUser() {
  return !!(window.isAdminRole && window.isAdminRole());
}

function getModalFieldElement(fieldName) {
  return document.querySelector(`#modalGrid [data-field="${fieldName}"]`);
}

function getSelectedCustomerPatchpanelId() {
  const raw = String(getModalFieldElement("customer_patchpanel_id")?.value || "").trim();
  const num = Number(raw);
  return Number.isFinite(num) && num > 0 ? num : null;
}

function getSelectedZPortRaw() {
  return String(getModalFieldElement("customer_port_label")?.value || "").trim();
}

function setSelectedZPortRaw(value) {
  const el = getModalFieldElement("customer_port_label");
  if (el) el.value = String(value || "").trim();
}

function setZPortHint(message) {
  const box = $("zPortHint");
  if (box) box.textContent = message || "";
}

function setZPortStatus(message, loading = false) {
  const box = $("zPortStatus");
  if (!box) return;
  box.innerHTML = loading
    ? `<span class="spinner"></span><span>${escapeHtml(message || "")}</span>`
    : `<span>${escapeHtml(message || "")}</span>`;
}

function zPortBadge(port) {
  const unavailable = String(port?.status || "").toLowerCase() === "unavailable";
  if (unavailable) return '<span class="badge badge-danger">n/a</span>';
  const occupied = !!(port?.is_occupied || port?.occupied || port?.trunk_present);
  return occupied
    ? '<span class="badge badge-warning">belegt</span>'
    : '<span class="badge badge-success">frei</span>';
}

function renderZPortDetail(port) {
  const box = $("zPortDetail");
  if (!box) return;
  if (!port) {
    box.innerHTML = '<div class="small muted">Port auswaehlen, um Details zu sehen.</div>';
    return;
  }

  const label = port.port_label || port.port_number || "-";
  const number = port.port_number || "-";
  const occupied = !!(port.is_occupied || port.occupied || port.trunk_present);
  const trunkPresent = port.trunk_present !== undefined ? !!port.trunk_present : occupied;
  const unavailable = String(port.status || "").toLowerCase() === "unavailable";

  if (unavailable) {
    box.innerHTML = `
      <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(label)} (#${escapeHtml(String(number))})</div>
      <div class="small muted">Status: nicht verfuegbar</div>
    `;
    return;
  }

  if (!occupied) {
    box.innerHTML = `
      <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(label)} (#${escapeHtml(String(number))})</div>
      <div class="small"><b>Status:</b> frei</div>
      <div class="small"><b>Trunk present:</b> ${trunkPresent ? "ja" : "nein"}</div>
      <div class="small muted">Port kann fuer neue Trunk-/Kundenbelegung genutzt werden.</div>
    `;
    return;
  }

  box.innerHTML = `
    <div style="font-weight:700; margin-bottom:6px;">Port ${escapeHtml(label)} (#${escapeHtml(String(number))})</div>
    <div class="small"><b>Status:</b> belegt</div>
    <div class="small"><b>occupied_by_serial:</b> <span class="mono">${escapeHtml(port.serial || "-")}</span></div>
    <div class="small"><b>customer:</b> ${escapeHtml(port.customer || "-")}</div>
    <div class="small"><b>side:</b> ${escapeHtml(port.side || "-")}</div>
    <div class="small"><b>cross_connect_id:</b> ${escapeHtml(String(port.cross_connect_id || "-"))}</div>
    <div class="small"><b>trunk present:</b> ${trunkPresent ? "ja" : "nein"}</div>
  `;
}

function renderZPortTable() {
  const body = $("zPortTableBody");
  if (!body) return;
  body.innerHTML = "";

  const ports = Array.isArray(state.zPortPicker.ports) ? state.zPortPicker.ports : [];
  for (const port of ports) {
    const selected = Number(port.port_number || 0) === Number(state.zPortPicker.selectedPortNumber || 0);
    const tr = document.createElement("tr");
    if (selected) tr.style.outline = "2px solid rgba(59,130,246,.55)";
    tr.innerHTML = `
      <td>${escapeHtml(String(port.port_number || "-"))}</td>
      <td>${escapeHtml(port.port_label || "-")}</td>
      <td>${zPortBadge(port)}</td>
      <td class="mono">${escapeHtml(port.serial || "-")}</td>
      <td>${escapeHtml(port.customer || "-")}</td>
      <td>${escapeHtml(port.side || "-")}</td>
      <td>${(port.trunk_present !== undefined ? !!port.trunk_present : !!(port.is_occupied || port.occupied)) ? "ja" : "nein"}</td>
    `;
    tr.addEventListener("mouseenter", () => renderZPortDetail(port));
    tr.addEventListener("click", () => onZPortClicked(port));
    body.appendChild(tr);
  }
}

function renderZPortGrid() {
  const grid = $("zPortGrid");
  if (!grid) return;
  grid.innerHTML = "";

  const allowOverride = !!state.zPortPicker.allowOverride && isAdminUser();
  const ports = Array.isArray(state.zPortPicker.ports) ? state.zPortPicker.ports : [];

  for (const port of ports) {
    const occupied = !!(port.is_occupied || port.occupied || port.trunk_present);
    const unavailable = String(port.status || "").toLowerCase() === "unavailable";
    const blocked = occupied && !allowOverride;
    const selected = Number(port.port_number || 0) === Number(state.zPortPicker.selectedPortNumber || 0);

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `zport-tile ${unavailable ? "unavailable" : (occupied ? "occupied" : "free")} ${blocked ? "blocked" : ""} ${selected ? "selected" : ""}`;
    btn.innerHTML = `<span>${escapeHtml(port.port_label || String(port.port_number || "-"))}</span><span class="dot"></span>`;
    btn.title = unavailable
      ? "Port nicht verfuegbar"
      : (occupied ? "Port belegt" : "Port frei");
    btn.addEventListener("mouseenter", () => renderZPortDetail(port));
    btn.addEventListener("click", () => onZPortClicked(port));
    grid.appendChild(btn);
  }
}

function closeZPortPicker() {
  $("zPortBackdrop").style.display = "none";
}

async function openZPortPicker() {
  const panelId = getSelectedCustomerPatchpanelId();
  if (!panelId) {
    showToast("Bitte zuerst eine gueltige Z-Seite Patchpanel ID setzen", "error");
    return;
  }

  state.zPortPicker.panelId = panelId;
  state.zPortPicker.panelMeta = null;
  state.zPortPicker.ports = [];
  state.zPortPicker.selectedPortNumber = null;

  const selectedPortRaw = getSelectedZPortRaw().toLowerCase();
  $("zPortBackdrop").style.display = "block";
  $("zPortTitle").textContent = `Z-Port Auswahl (Patchpanel ${panelId})`;
  $("zPortPanelMeta").textContent = `Patchpanel ID: ${panelId}`;
  setZPortStatus("Ports werden geladen...", true);
  renderZPortDetail(null);

  try {
    const res = await fetch(`${API_PATCHPANELS}/${panelId}/ports`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);

    state.zPortPicker.panelMeta = data.patchpanel || { id: panelId };
    const ports = Array.isArray(data.ports) ? data.ports.slice() : [];
    ports.sort((a, b) => Number(a.port_number || 0) - Number(b.port_number || 0));
    state.zPortPicker.ports = ports;

    const found = ports.find((p) => {
      const label = String(p.port_label || "").trim().toLowerCase();
      const num = String(p.port_number || "").trim().toLowerCase();
      return selectedPortRaw && (selectedPortRaw === label || selectedPortRaw === num);
    });
    state.zPortPicker.selectedPortNumber = found ? Number(found.port_number || 0) : null;

    const metaName = state.zPortPicker.panelMeta?.name || `Patchpanel ${panelId}`;
    const metaLoc = state.zPortPicker.panelMeta?.location || "-";
    $("zPortTitle").textContent = `Z-Port Auswahl - ${metaName}`;
    $("zPortPanelMeta").textContent = `${metaName} | ${metaLoc} | Ports: ${ports.length}`;
    setZPortStatus(`${ports.length} Ports geladen`);
    renderZPortGrid();
    renderZPortTable();
    renderZPortDetail(found || ports[0] || null);
  } catch (error) {
    setZPortStatus(`Fehler: ${error.message}`);
    showToast(`Z-Port Popup konnte nicht geladen werden: ${error.message}`, "error");
  }
}

function onZPortClicked(port) {
  renderZPortDetail(port);
  const unavailable = String(port?.status || "").toLowerCase() === "unavailable";
  if (unavailable) {
    showToast("Port nicht verfuegbar", "error");
    return;
  }

  const occupied = !!(port?.is_occupied || port?.occupied || port?.trunk_present);
  const allowOverride = !!state.zPortPicker.allowOverride && isAdminUser();
  if (occupied && !allowOverride) {
    showToast("Port belegt (Trunk vorhanden/benutzt). Auswahl blockiert.", "error");
    return;
  }

  const value = String(port.port_label || port.port_number || "").trim();
  if (!value) {
    showToast("Port hat kein gueltiges Label", "error");
    return;
  }

  state.zPortPicker.selectedPortNumber = Number(port.port_number || 0);
  setSelectedZPortRaw(value);
  setZPortHint(`Z-Port gesetzt: ${value}${occupied ? " (Override)" : ""}`);
  renderZPortGrid();
  renderZPortTable();
  if (occupied && allowOverride) {
    showToast(`Port ${value} ist belegt. Auswahl nur wegen Admin-Override erlaubt.`, "info");
  }
  showToast(`Z-Port ${value} uebernommen`, "success");
  closeZPortPicker();
}

function bindModalPortPicker(readOnly) {
  const ppInput = getModalFieldElement("customer_patchpanel_id");
  const openBtn = $("btnOpenZPortPicker");
  const overrideWrap = $("zPortOverrideWrap");
  const overrideBox = $("zPortAllowOverride");

  if (overrideWrap) {
    overrideWrap.style.display = isAdminUser() ? "inline-flex" : "none";
  }
  if (overrideBox) {
    state.zPortPicker.allowOverride = false;
    overrideBox.checked = false;
    overrideBox.onchange = () => {
      state.zPortPicker.allowOverride = !!overrideBox.checked && isAdminUser();
      renderZPortGrid();
      renderZPortTable();
    };
  }

  if (openBtn) {
    openBtn.disabled = !!readOnly;
    openBtn.onclick = () => {
      if (readOnly) return;
      openZPortPicker();
    };
  }

  if (ppInput) {
    const updateHint = () => {
      const ppId = getSelectedCustomerPatchpanelId();
      if (!ppId) {
        setZPortHint("Bitte zuerst eine gueltige Kunde Patchpanel ID eingeben.");
        return;
      }
      const currentPort = getSelectedZPortRaw();
      setZPortHint(currentPort ? `Aktueller Z-Port: ${currentPort}` : `Patchpanel ${ppId} bereit - Z-Port auswaehlen.`);
    };
    updateHint();

    ppInput.addEventListener("change", async () => {
      updateHint();
      if (!readOnly && getSelectedCustomerPatchpanelId()) {
        await openZPortPicker();
      }
    });
  }
}

function openModal(mode, item) {
  state.modalMode = mode;
  state.modalItem = item || null;

  const titleMap = {
    details: "Cross Connect Details",
    edit: `Cross Connect #${item?.id || ""} bearbeiten`,
    create: "Neue Cross Connect",
  };
  $("modalTitle").textContent = titleMap[mode] || "Cross Connect";

  const readOnly = mode === "details";
  const editDisabled = mode === "details";
  const data = item || {};
  const statusOptions = [
    "planned",
    "review",
    "in_progress",
    "done",
    "troubleshoot",
    "pending_serial",
    "pending_install",
    "pending_deinstall",
    "pending_move",
    "pending_path_move",
    "active",
    "deinstalled",
  ];

  const fields = [
    modalField("Serial", "serial", data.serial || "", { readOnly }),
    modalField("Switch Name", "switch_name", data.switch_name || "", { readOnly }),
    modalField("Switch Port", "switch_port", data.switch_port || "", { readOnly }),
    modalField("A Patchpanel", "a_patchpanel_id", data.a_patchpanel_id || "", { readOnly }),
    modalField("A Port", "a_port_label", data.a_port_label || "", { readOnly }),
    modalField("BB IN Instance", "backbone_in_instance_id", data.backbone_in_instance_id || "", { readOnly }),
    modalField("BB IN Port", "backbone_in_port_label", data.backbone_in_port_label || "", { readOnly }),
    modalField("BB OUT Instance", "backbone_out_instance_id", data.backbone_out_instance_id || "", { readOnly }),
    modalField("BB OUT Port", "backbone_out_port_label", data.backbone_out_port_label || "", { readOnly }),
    modalField("Kunde Patchpanel ID", "customer_patchpanel_id", data.customer_patchpanel_id || "", { readOnly, type: "number" }),
    modalField("Kunde Port", "customer_port_label", data.customer_port_label || "", { readOnly }),
    `
    <div class="field span-2">
      <label class="small muted">Z-Seite Portwahl</label>
      <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
        <button class="btn" type="button" id="btnOpenZPortPicker" ${readOnly ? "disabled" : ""}>Z-Port auswaehlen</button>
        <span class="small muted" id="zPortHint"></span>
      </div>
    </div>
    `,
    modalField("Status", "status", data.status || "planned", {
      select: statusOptions,
      disabled: editDisabled,
      span2: mode !== "create",
    }),
  ];

  $("modalGrid").innerHTML = fields.join("\n");
  bindModalPortPicker(readOnly);
  $("modalBackdrop").style.display = "block";

  const canSave = mode !== "details" && window.isAdminRole && window.isAdminRole();
  $("modalSave").style.display = canSave ? "inline-flex" : "none";
}

function closeModal() {
  state.modalMode = null;
  state.modalItem = null;
  closeZPortPicker();
  $("modalBackdrop").style.display = "none";
}

function collectModalData() {
  const data = {};
  document.querySelectorAll("#modalGrid [data-field]").forEach((el) => {
    data[el.dataset.field] = (el.value || "").trim();
  });
  return data;
}

async function openDetails(id) {
  const item = state.items.find((x) => Number(x.id) === Number(id));
  if (item) {
    openModal("details", item);
    return;
  }
  try {
    const res = await fetch(`${API}/item/${id}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
    openModal("details", data.item || {});
  } catch (error) {
    showToast(`Details konnten nicht geladen werden: ${error.message}`, "error");
  }
}

async function openEdit(id) {
  try {
    const res = await fetch(`${API}/item/${id}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
    openModal("edit", data.item || {});
  } catch (error) {
    showToast(`Bearbeiten fehlgeschlagen: ${error.message}`, "error");
  }
}

function validateCreatePayload(payload) {
  const required = [
    "switch_name",
    "switch_port",
    "a_patchpanel_id",
    "a_port_label",
    "backbone_in_instance_id",
    "backbone_in_port_label",
    "backbone_out_instance_id",
    "backbone_out_port_label",
    "customer_patchpanel_id",
    "customer_port_label",
  ];
  for (const key of required) {
    if (!payload[key]) throw new Error(`Pflichtfeld fehlt: ${key}`);
  }
}

async function validateZPortSelectionBeforeSave(payload) {
  const ppId = Number(payload.customer_patchpanel_id || 0);
  const zPort = String(payload.customer_port_label || "").trim();
  if (!ppId || !zPort) return;

  const res = await fetch(`${API_PATCHPANELS}/${ppId}/ports`);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.detail || `Patchpanel Ports HTTP ${res.status}`);

  const ports = Array.isArray(data.ports) ? data.ports : [];
  const found = ports.find((p) => {
    const label = String(p.port_label || "").trim().toLowerCase();
    const number = String(p.port_number || "").trim().toLowerCase();
    const needle = zPort.toLowerCase();
    return needle === label || needle === number;
  });
  if (!found) return;

  const unavailable = String(found.status || "").toLowerCase() === "unavailable";
  if (unavailable) {
    throw new Error("Ausgewaehlter Z-Port ist nicht verfuegbar");
  }

  const occupied = !!(found.is_occupied || found.occupied || found.trunk_present);
  if (occupied && !(state.zPortPicker.allowOverride && isAdminUser())) {
    throw new Error("Z-Port ist belegt (Trunk vorhanden/benutzt). Override erforderlich (Admin).");
  }
}

async function saveModal() {
  if (!state.modalMode) return;
  const raw = collectModalData();
  const payload = { ...raw };
  if (payload.customer_patchpanel_id) payload.customer_patchpanel_id = Number(payload.customer_patchpanel_id);
  if (!payload.serial) delete payload.serial;

  $("modalSave").disabled = true;
  $("modalSave").textContent = "Speichern...";

  try {
    if (state.modalMode === "create") {
      validateCreatePayload(payload);
      await validateZPortSelectionBeforeSave(payload);
      const res = await fetch(`${API}/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
      showToast("Cross Connect erstellt", "success");
    } else if (state.modalMode === "edit") {
      const id = state.modalItem?.id;
      if (!id) throw new Error("Kein Datensatz ausgewaehlt");
      await validateZPortSelectionBeforeSave(payload);
      const editPayload = {
        backbone_in_instance_id: payload.backbone_in_instance_id || null,
        backbone_in_port_label: payload.backbone_in_port_label || null,
        backbone_out_instance_id: payload.backbone_out_instance_id || null,
        backbone_out_port_label: payload.backbone_out_port_label || null,
        customer_patchpanel_id: payload.customer_patchpanel_id || null,
        customer_port_label: payload.customer_port_label || null,
        status: payload.status || undefined,
        assigned_to: payload.assigned_to || undefined,
        current_user: localStorage.getItem("username") || sessionStorage.getItem("username") || undefined,
      };
      const res = await fetch(`${API}/item/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editPayload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.detail || `HTTP ${res.status}`);
      showToast("Cross Connect aktualisiert", "success");
    }

    closeModal();
    await loadList();
  } catch (error) {
    showToast(`Speichern fehlgeschlagen: ${error.message}`, "error");
  } finally {
    $("modalSave").disabled = false;
    $("modalSave").textContent = "Speichern";
  }
}

function handleTableClick(ev) {
  const trigger = ev.target.closest("[data-action]");
  if (!trigger) return;
  ev.preventDefault();
  const action = trigger.dataset.action;
  const id = Number(trigger.dataset.id || 0);
  if (!id) return;
  if (action === "details") openDetails(id);
  if (action === "edit") openEdit(id);
}

function applyInitialFiltersFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const status = (params.get("status") || "").trim().toLowerCase();
  if (status && $("statusFilter")) {
    const option = Array.from($("statusFilter").options).find((x) => String(x.value).toLowerCase() === status);
    if (option) $("statusFilter").value = status;
  }
  const search = (params.get("q") || "").trim();
  if (search && $("searchInput")) $("searchInput").value = search;
}

function installHandlers() {
  $("btnRefresh")?.addEventListener("click", loadList);
  $("btnNew")?.addEventListener("click", () => openModal("create", {}));
  $("btnKwPlanning")?.addEventListener("click", () => {
    window.location.href = "kw-planning.html";
  });

  $("statusFilter")?.addEventListener("change", loadList);
  $("ccTableBody")?.addEventListener("click", handleTableClick);

  const triggerOnEnter = (id) => {
    $(id)?.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        loadList();
      }
    });
  };
  triggerOnEnter("searchInput");
  triggerOnEnter("customerFilter");

  $("modalClose")?.addEventListener("click", closeModal);
  $("modalCancel")?.addEventListener("click", closeModal);
  $("modalSave")?.addEventListener("click", saveModal);

  $("modalBackdrop")?.addEventListener("click", (ev) => {
    if (ev.target && ev.target.id === "modalBackdrop") closeModal();
  });

  $("zPortClose")?.addEventListener("click", closeZPortPicker);
  $("zPortBackdrop")?.addEventListener("click", (ev) => {
    if (ev.target && ev.target.id === "zPortBackdrop") closeZPortPicker();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  applyInitialFiltersFromQuery();
  installHandlers();
  loadList();
});
