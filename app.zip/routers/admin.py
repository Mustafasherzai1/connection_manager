﻿from __future__ import annotations

import secrets
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from audit import write_audit_log
from database import get_db
from security import (
    PERMISSIONS,
    get_effective_permissions,
    hash_password,
    is_admin_role,
    normalize_role,
    require_permissions,
)


router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


class CreateUserIn(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    password: Optional[str] = Field(None, min_length=1, max_length=200)
    role: str = "viewer"
    is_active: bool = True
    temp_password: bool = False


class RoleUpdateIn(BaseModel):
    role: str


class GrantIn(BaseModel):
    permission: str
    valid_from: Optional[datetime] = None
    valid_until: Optional[datetime] = None


class RevokeIn(BaseModel):
    reason: Optional[str] = None


def _require_admin_user(current_user: Dict[str, Any]) -> None:
    if not is_admin_role(current_user.get("role")):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")


def _get_user_by_id(db: Session, user_id: int) -> Dict[str, Any] | None:
    row = db.execute(
        text(
            """
            SELECT id, username, role, is_active, created_at
            FROM public.users
            WHERE id = :id
            LIMIT 1
            """
        ),
        {"id": int(user_id)},
    ).mappings().first()
    if not row:
        return None
    return {
        "id": int(row.get("id")),
        "username": row.get("username"),
        "role": normalize_role(row.get("role")),
        "is_active": bool(row.get("is_active", True)),
        "created_at": row.get("created_at"),
    }


@router.get("/ping")
def admin_ping(current_user=Depends(require_permissions("admin:settings", allow_roles={"admin", "superadmin"}))):
    return {"ok": True, "message": "admin api"}


@router.get("/users")
def list_users(
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("users:manage", allow_roles={"admin", "superadmin"})),
):
    # Reset session in case a previous statement failed (e.g., missing migration)
    db.rollback()
    rows = db.execute(
        text(
            """
            SELECT id, username, role, is_active, created_at
            FROM public.users
            ORDER BY id ASC
            """
        )
    ).mappings().all()

    items: List[Dict[str, Any]] = []
    for r in rows:
        user = {
            "id": int(r.get("id")),
            "username": r.get("username"),
            "role": normalize_role(r.get("role")),
            "is_active": bool(r.get("is_active", True)),
            "created_at": r.get("created_at"),
        }

        try:
            grants = db.execute(
                text(
                    """
                    SELECT id, permission, valid_from, valid_until
                    FROM public.user_permission_grants
                    WHERE user_id = :uid
                      AND revoked_at IS NULL
                    ORDER BY id DESC
                    """
                ),
                {"uid": int(user["id"])},
            ).mappings().all()
        except Exception:
            db.rollback()
            grants = []

        user["grants"] = [
            {
                "id": int(g.get("id")),
                "permission": g.get("permission"),
                "valid_from": g.get("valid_from"),
                "valid_until": g.get("valid_until"),
            }
            for g in grants
        ]
        user["effective_permissions"] = sorted(get_effective_permissions(db, user))
        items.append(user)

    return {"items": items, "count": len(items)}


@router.post("/users", status_code=status.HTTP_201_CREATED)
def create_user(
    payload: CreateUserIn,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("users:manage", allow_roles={"admin", "superadmin"})),
):
    _require_admin_user(current_user)

    username = payload.username.strip()
    if not username:
        raise HTTPException(400, "Username required")

    role = normalize_role(payload.role)
    if role not in {"viewer", "techniker", "admin", "superadmin"}:
        raise HTTPException(400, "Invalid role")

    # Only superadmin can create another superadmin
    if role == "superadmin" and normalize_role(current_user.get("role")) != "superadmin":
        raise HTTPException(status_code=403, detail="Forbidden")

    exists = db.execute(
        text("SELECT 1 FROM public.users WHERE username = :u"),
        {"u": username},
    ).first()
    if exists:
        raise HTTPException(400, "Username already exists")

    raw_password = payload.password
    generated = False
    if not raw_password or payload.temp_password:
        raw_password = secrets.token_urlsafe(10)
        generated = True

    pw_hash = hash_password(raw_password)

    db.rollback()
    with db.begin():
        row = db.execute(
            text(
                """
                INSERT INTO public.users (username, password_hash, role, is_active)
                VALUES (:u, :ph, :role, :active)
                RETURNING id
                """
            ),
            {
                "u": username,
                "ph": pw_hash,
                "role": role,
                "active": bool(payload.is_active),
            },
        ).mappings().first()
        user_id = int(row["id"]) if row else None

        write_audit_log(
            db,
            user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            action="CREATE_USER",
            entity_type="user",
            entity_id=user_id,
            details={"role": role, "generated_password": generated},
            actor_user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            target_user_id=user_id,
            endpoint=str(request.url.path),
            ip=(request.client.host if request.client else None),
        )

    return {
        "id": user_id,
        "username": username,
        "role": role,
        "is_active": bool(payload.is_active),
        "temp_password": raw_password if generated else None,
    }


@router.patch("/users/{user_id}/role")
def update_user_role(
    user_id: int,
    payload: RoleUpdateIn,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("users:manage", allow_roles={"admin", "superadmin"})),
):
    _require_admin_user(current_user)

    target = _get_user_by_id(db, user_id)
    if not target:
        raise HTTPException(404, "User not found")

    new_role = normalize_role(payload.role)
    if new_role not in {"viewer", "techniker", "admin", "superadmin"}:
        raise HTTPException(400, "Invalid role")

    actor_role = normalize_role(current_user.get("role"))
    if target.get("role") == "superadmin" and actor_role != "superadmin":
        raise HTTPException(status_code=403, detail="Forbidden")
    if new_role == "superadmin" and actor_role != "superadmin":
        raise HTTPException(status_code=403, detail="Forbidden")

    if new_role == target.get("role"):
        return {"success": True, "role": new_role}

    db.rollback()
    with db.begin():
        db.execute(
            text("UPDATE public.users SET role = :r WHERE id = :id"),
            {"r": new_role, "id": int(user_id)},
        )
        write_audit_log(
            db,
            user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            action="SET_ROLE",
            entity_type="user",
            entity_id=int(user_id),
            details={"from": target.get("role"), "to": new_role},
            actor_user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            target_user_id=int(user_id),
            endpoint=str(request.url.path),
            ip=(request.client.host if request.client else None),
        )

    return {"success": True, "role": new_role}


@router.post("/users/{user_id}/grants")
def grant_permission(
    user_id: int,
    payload: GrantIn,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("permissions:grant", allow_roles={"admin", "superadmin"})),
):
    _require_admin_user(current_user)

    target = _get_user_by_id(db, user_id)
    if not target:
        raise HTTPException(404, "User not found")

    perm = (payload.permission or "").strip()
    if perm not in PERMISSIONS:
        raise HTTPException(400, "Invalid permission")

    valid_from = payload.valid_from or datetime.utcnow()
    valid_until = payload.valid_until

    db.rollback()
    with db.begin():
        row = db.execute(
            text(
                """
                INSERT INTO public.user_permission_grants
                  (user_id, permission, valid_from, valid_until, granted_by_user_id)
                VALUES
                  (:uid, :perm, :vf, :vu, :by)
                RETURNING id
                """
            ),
            {
                "uid": int(user_id),
                "perm": perm,
                "vf": valid_from,
                "vu": valid_until,
                "by": int(current_user.get("id")),
            },
        ).mappings().first()

        grant_id = int(row["id"]) if row else None

        write_audit_log(
            db,
            user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            action="GRANT_PERMISSION",
            entity_type="user_permission_grant",
            entity_id=grant_id,
            details={
                "permission": perm,
                "valid_from": valid_from.isoformat() if valid_from else None,
                "valid_until": valid_until.isoformat() if valid_until else None,
            },
            actor_user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            target_user_id=int(user_id),
            endpoint=str(request.url.path),
            ip=(request.client.host if request.client else None),
        )

    return {"success": True, "grant_id": grant_id}


@router.post("/users/{user_id}/grants/{grant_id}/revoke")
def revoke_permission(
    user_id: int,
    grant_id: int,
    payload: RevokeIn,
    request: Request,
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("permissions:grant", allow_roles={"admin", "superadmin"})),
):
    _require_admin_user(current_user)

    row = db.execute(
        text(
            """
            SELECT id, permission
            FROM public.user_permission_grants
            WHERE id = :gid AND user_id = :uid AND revoked_at IS NULL
            """
        ),
        {"gid": int(grant_id), "uid": int(user_id)},
    ).mappings().first()
    if not row:
        raise HTTPException(404, "Grant not found")

    db.rollback()
    with db.begin():
        db.execute(
            text(
                """
                UPDATE public.user_permission_grants
                SET revoked_at = NOW(),
                    revoked_by_user_id = :by,
                    revoke_reason = :reason
                WHERE id = :gid
                """
            ),
            {
                "by": int(current_user.get("id")),
                "reason": payload.reason,
                "gid": int(grant_id),
            },
        )

        write_audit_log(
            db,
            user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            action="REVOKE_PERMISSION",
            entity_type="user_permission_grant",
            entity_id=int(grant_id),
            details={
                "permission": row.get("permission"),
                "reason": payload.reason,
            },
            actor_user_id=current_user.get("id") if isinstance(current_user, dict) else None,
            target_user_id=int(user_id),
            endpoint=str(request.url.path),
            ip=(request.client.host if request.client else None),
        )

    return {"success": True}


@router.get("/audit-log")
def read_audit_log(
    actor_user_id: Optional[int] = None,
    target_user_id: Optional[int] = None,
    action: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 200,
    db: Session = Depends(get_db),
    current_user=Depends(require_permissions("logs:view", allow_roles={"admin", "superadmin"})),
):
    if limit > 500:
        limit = 500

    conditions = []
    params: Dict[str, Any] = {"limit": int(limit)}

    if actor_user_id:
        conditions.append("COALESCE(actor_user_id, user_id) = :actor")
        params["actor"] = int(actor_user_id)
    if target_user_id:
        conditions.append("target_user_id = :target")
        params["target"] = int(target_user_id)
    if action:
        conditions.append("action = :action")
        params["action"] = action
    if date_from:
        conditions.append("COALESCE(ts, created_at) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        conditions.append("COALESCE(ts, created_at) <= :date_to")
        params["date_to"] = date_to

    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    rows = db.execute(
        text(
            f"""
            SELECT
              COALESCE(ts, created_at) AS ts,
              COALESCE(actor_user_id, user_id) AS actor_user_id,
              action,
              target_user_id,
              COALESCE(details_json, details) AS details_json,
              endpoint,
              ip
            FROM public.audit_log
            {where}
            ORDER BY COALESCE(ts, created_at) DESC
            LIMIT :limit
            """
        ),
        params,
    ).mappings().all()

    items = [
        {
            "ts": r.get("ts"),
            "actor_user_id": r.get("actor_user_id"),
            "action": r.get("action"),
            "target_user_id": r.get("target_user_id"),
            "details": r.get("details_json"),
            "endpoint": r.get("endpoint"),
            "ip": r.get("ip"),
        }
        for r in rows
    ]

    return {"items": items, "count": len(items)}
