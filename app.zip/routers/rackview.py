from fastapi import APIRouter, Depends, HTTPException, Query, Body
from sqlalchemy.orm import Session
from sqlalchemy import func, text
from typing import List
from datetime import datetime

from database import get_db
from crud import (
    get_all_rooms,
    get_room_overview,
    get_switch_details,
    get_precabling_stats,
    get_switches_in_room
)
from models import (
    RoomOverview,
    PatchPanelInstance,
    PatchPanelPort,
    PatchPanelInstanceRead,
    PreCabledLink
)

router = APIRouter()

# =========================================================
# PATCHPANEL VIEW (Dropdown + Ports)
# =========================================================

@router.get("/patchpanel-rooms")
def get_patchpanel_rooms(db: Session = Depends(get_db)):
    rows = db.execute(text("""
        SELECT DISTINCT room
        FROM patchpanel_instances
        WHERE room IS NOT NULL AND room <> ''
        ORDER BY room
    """)).fetchall()

    return {"success": True, "rooms": [r.room for r in rows]}


@router.get("/patchpanel-instances")
def get_patchpanel_instances_by_room(
    room: str = Query(..., description="Room Name, z.B. '5.13S1'"),
    db: Session = Depends(get_db)
):
    norms = _room_norm_variants(room)
    if not norms:
        return {"success": True, "instances": []}

    params = {f"n{i}": n for i, n in enumerate(norms)}
    where_in = ", ".join([f":n{i}" for i in range(len(norms))])

    rows = db.execute(text(f"""
        SELECT instance_id, rack_unit, panel_type, total_ports
        FROM patchpanel_instances
        WHERE regexp_replace(upper(room), '[^A-Z0-9]', '', 'g') IN ({where_in})
        ORDER BY rack_unit, instance_id
    """), params).fetchall()

    return {
        "success": True,
        "instances": [
            {
                "instance_id": r.instance_id,
                "rack_unit": r.rack_unit,
                "panel_type": r.panel_type,
                "total_ports": r.total_ports
            } for r in rows
        ]
    }


@router.get("/patchpanel-ports")
def get_patchpanel_ports(
    instance_id: str = Query(..., description="PatchPanel ID wie '5.4S6/RU1'", example="5.4S6/RU1"),
    db: Session = Depends(get_db)
):
    """
    ✅ FIX:
    - connected  = Peer vorhanden (Info, NICHT belegt)
    - occupied   = wirklich belegt (connected_to != '')
    - selectable = nur wenn NICHT occupied
    - RESPONSE: ports ist LISTE (frontend-friendly)
    """
    try:
        panel = db.execute(text("""
            SELECT id, room, rack_unit, total_ports, panel_type, instance_id
            FROM patchpanel_instances
            WHERE instance_id = :iid
            LIMIT 1
        """), {"iid": instance_id}).fetchone()

        if not panel:
            raise HTTPException(status_code=404, detail=f"PatchPanel '{instance_id}' nicht gefunden")

        ports = db.execute(text("""
            SELECT
                port_label,
                row_number,
                row_letter,
                position,
                status,
                peer_instance_id,
                peer_port_label,
                connected_to
            FROM patchpanel_ports
            WHERE patchpanel_id = :pid
            ORDER BY row_number, row_letter, position
            LIMIT 96
        """), {"pid": panel.id}).fetchall()

        ports_list = []
        peer_count = 0
        occupied_count = 0

        for p in ports:
            ct = (p.connected_to or "").strip()
            peer_present = (p.peer_instance_id is not None) and (str(p.peer_instance_id).strip() != "")
            occupied = (ct != "")                 # ✅ NUR connected_to blockiert
            selectable = not occupied              # ✅ UI: grün wenn True

            if peer_present:
                peer_count += 1
            if occupied:
                occupied_count += 1

            ports_list.append({
                "label": p.port_label,
                "row": p.row_number,
                "letter": p.row_letter,
                "position": p.position,

                # original status bleibt drin (falls UI irgendwo nutzt)
                "status": p.status,

                # ✅ eindeutiger status für UI:
                "ui_status": ("occupied" if occupied else ("connected" if peer_present else "free")),

                # ✅ wichtig:
                "connected": peer_present,
                "occupied": occupied,
                "selectable": selectable,

                "peer": {
                    "instance_id": p.peer_instance_id,
                    "port_label": p.peer_port_label
                } if peer_present else None,

                "switch_connection": ct if occupied else None
            })

        total = len(ports_list)

        # ✅ WICHTIG: ports als LISTE zurückgeben + meta extra
        return {
            "success": True,
            "patchpanel": {
                "instance_id": panel.instance_id,
                "id": panel.id,
                "room": panel.room,
                "rack_unit": panel.rack_unit,
                "total_ports": panel.total_ports,
                "panel_type": panel.panel_type
            },
            "ports": ports_list,
            "ports_meta": {
                "total": total,
                "connected": peer_count,                 # peer count (info)
                "occupied": occupied_count,              # real occupied
                "available": total - occupied_count,     # real available
                "utilization_percent": round((occupied_count / total * 100), 2) if total else 0
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@router.get("/patchpanel-backbone-instances")
def get_backbone_instances_by_room(
    room: str = Query(..., description="Room Name, z.B. '5.13S1'"),
    db: Session = Depends(get_db)
):
    """
    Liefert NUR Panels im Raum, die Ports haben, deren Peer in einem ANDEREN Raum ist.
    => das sind deine 'kleinen Backbone PPs' die in andere Räume gehen.
    """
    rows = db.execute(text("""
        SELECT DISTINCT
            i.instance_id, i.rack_unit, i.panel_type, i.total_ports
        FROM patchpanel_instances i
        JOIN patchpanel_ports p
          ON p.patchpanel_id = i.id
        JOIN patchpanel_instances peer
          ON peer.instance_id = p.peer_instance_id
        WHERE i.room = :room
          AND p.peer_instance_id IS NOT NULL
          AND peer.room IS NOT NULL AND peer.room <> ''
          AND peer.room <> :room
        ORDER BY i.rack_unit, i.instance_id
    """), {"room": room}).fetchall()

    return {
        "success": True,
        "instances": [
            {
                "instance_id": r.instance_id,
                "rack_unit": r.rack_unit,
                "panel_type": r.panel_type,
                "total_ports": r.total_ports
            } for r in rows
        ]
    }
    


@router.get("/patchpanel-peer")
def get_patchpanel_peer(
    instance_id: str = Query(...),
    port_label: str = Query(...),
    db: Session = Depends(get_db)
):
    # instance meta
    panel = db.execute(text("""
        SELECT id, room
        FROM patchpanel_instances
        WHERE instance_id = :iid
        LIMIT 1
    """), {"iid": instance_id}).fetchone()

    if not panel:
        raise HTTPException(status_code=404, detail=f"PatchPanel '{instance_id}' nicht gefunden")

    # port + peer
    port = db.execute(text("""
        SELECT peer_instance_id, peer_port_label, status, connected_to
        FROM patchpanel_ports
        WHERE patchpanel_id = :pid AND port_label = :lbl
        LIMIT 1
    """), {"pid": panel.id, "lbl": port_label}).fetchone()

    if not port:
        raise HTTPException(status_code=404, detail=f"Port '{port_label}' nicht gefunden")

    # peer room (wenn peer existiert)
    peer_room = None
    if port.peer_instance_id:
        peer_row = db.execute(text("""
            SELECT room
            FROM patchpanel_instances
            WHERE instance_id = :piid
            LIMIT 1
        """), {"piid": port.peer_instance_id}).fetchone()
        peer_room = peer_row.room if peer_row else None

    ct = (port.connected_to or "").strip()
    peer_present = (port.peer_instance_id is not None)
    occupied = (ct != "")

    return {
        "success": True,
        "instance_id": instance_id,
        "instance_room": panel.room,
        "port_label": port_label,

        "connected": peer_present,   # peer-info
        "occupied": occupied,        # real occupied

        "peer_instance_id": port.peer_instance_id,
        "peer_port_label": port.peer_port_label,
        "peer_room": peer_room,

        "switch_connection": ct if occupied else None
    }
@router.get("/patchpanel-backbone-out")
def get_backbone_out_panels(
    room: str = Query(...),
    db: Session = Depends(get_db)
):
    """
    Step2: nur Panels IM room, die Ports haben, deren Peer in ANDEREM room liegt.
    (= deine grünen Panels)
    """
    rows = db.execute(text("""
        SELECT DISTINCT
            i.instance_id, i.rack_unit, i.panel_type, i.total_ports
        FROM patchpanel_instances i
        JOIN patchpanel_ports p ON p.patchpanel_id = i.id
        JOIN patchpanel_instances peer ON peer.instance_id = p.peer_instance_id
        WHERE i.room = :room
          AND p.peer_instance_id IS NOT NULL
          AND peer.room IS NOT NULL AND peer.room <> ''
          AND peer.room <> :room
        ORDER BY i.rack_unit, i.instance_id
    """), {"room": room}).fetchall()

    return {
        "success": True,
        "instances": [
            {
                "instance_id": r.instance_id,
                "rack_unit": r.rack_unit,
                "panel_type": r.panel_type,
                "total_ports": r.total_ports
            } for r in rows
        ]
    }



# =========================================================
# CONNECTION WORKFLOW (Switch -> PreCabled -> Save Patch)
# =========================================================

@router.get("/precabled-by-switch")
def precabled_by_switch(
    switch_name: str = Query(...),
    switch_port: str = Query(...),
    db: Session = Depends(get_db)
):
    row = db.execute(text("""
        SELECT id, room, switch_name, switch_port, patchpanel_id, patchpanel_port, patchpanel_pair
        FROM pre_cabled_links
        WHERE switch_name = :sn AND switch_port = :sp
        ORDER BY id ASC
        LIMIT 1
    """), {"sn": switch_name, "sp": switch_port}).fetchone()

    if not row:
        raise HTTPException(status_code=404, detail="Kein Pre-Cabled Link für diesen Switch-Port gefunden")

    return {
        "success": True,
        "link": {
            "id": row.id,
            "room": row.room,
            "switch_name": row.switch_name,
            "switch_port": row.switch_port,
            "patchpanel_id": row.patchpanel_id,
            "patchpanel_port": row.patchpanel_port,
            "patchpanel_pair": row.patchpanel_pair
        }
    }


@router.get("/manual-patch")
def get_manual_patch(
    a_patchpanel_id: str = Query(...),
    a_port: str = Query(...),
    db: Session = Depends(get_db)
):
    row = db.execute(text("""
        SELECT id, a_patchpanel_id, a_port, b_instance_id, b_port_label, cable_type, note, created_by, created_at
        FROM manual_patches
        WHERE a_patchpanel_id = :aid AND a_port = :aport
        LIMIT 1
    """), {"aid": a_patchpanel_id, "aport": a_port}).fetchone()

    return {
        "success": True,
        "patch": {
            "id": row.id,
            "a_patchpanel_id": row.a_patchpanel_id,
            "a_port": row.a_port,
            "b_instance_id": row.b_instance_id,
            "b_port_label": row.b_port_label,
            "cable_type": row.cable_type,
            "note": row.note,
            "created_by": row.created_by,
            "created_at": row.created_at.isoformat() if row.created_at else None
        } if row else None
    }


@router.post("/manual-patch")
def create_manual_patch(
    payload: dict = Body(...),
    db: Session = Depends(get_db)
):
    a_id = (payload.get("a_patchpanel_id") or "").strip()
    a_port = (payload.get("a_port") or "").strip()
    b_iid = (payload.get("b_instance_id") or "").strip()
    b_port = (payload.get("b_port_label") or "").strip()

    if not a_id or not a_port or not b_iid or not b_port:
        raise HTTPException(status_code=400, detail="Missing fields")

    # Source schon dokumentiert?
    existing_a = db.execute(text("""
        SELECT b_instance_id, b_port_label
        FROM manual_patches
        WHERE a_patchpanel_id = :a_id AND a_port = :a_port
        LIMIT 1
    """), {"a_id": a_id, "a_port": a_port}).fetchone()

    if existing_a:
        raise HTTPException(status_code=409, detail=f"Source {a_id}/{a_port} ist schon dokumentiert")

    # Ziel schon dokumentiert?
    used_target = db.execute(text("""
        SELECT a_patchpanel_id, a_port
        FROM manual_patches
        WHERE b_instance_id = :b_iid AND b_port_label = :b_port
        LIMIT 1
    """), {"b_iid": b_iid, "b_port": b_port}).fetchone()

    if used_target:
        raise HTTPException(status_code=409, detail=f"Ziel {b_iid}/{b_port} ist schon belegt")

    # Ziel Panel
    panel = db.execute(text("""
        SELECT id, room
        FROM patchpanel_instances
        WHERE instance_id = :iid
        LIMIT 1
    """), {"iid": b_iid}).fetchone()

    if not panel:
        raise HTTPException(status_code=404, detail=f"Ziel Patchpanel '{b_iid}' nicht gefunden")

    # Ziel Port
    port_row = db.execute(text("""
        SELECT peer_instance_id, connected_to
        FROM patchpanel_ports
        WHERE patchpanel_id = :pid AND port_label = :lbl
        LIMIT 1
    """), {"pid": panel.id, "lbl": b_port}).fetchone()

    if not port_row:
        raise HTTPException(status_code=404, detail=f"Ziel Port '{b_port}' nicht gefunden")

    ct_existing = (port_row.connected_to or "").strip()

    # ✅ FIX: Peer bedeutet NICHT belegt – nur connected_to blockiert
    target_is_occupied = (ct_existing != "")
    if target_is_occupied:
        raise HTTPException(status_code=409, detail=f"Ziel-Port {b_iid}/{b_port} ist bereits belegt")

    # Insert
    db.execute(text("""
        INSERT INTO manual_patches (a_patchpanel_id, a_port, b_instance_id, b_port_label, cable_type, note, created_by)
        VALUES (:a_id, :a_port, :b_iid, :b_port, :cable_type, :note, :created_by)
    """), {
        "a_id": a_id,
        "a_port": a_port,
        "b_iid": b_iid,
        "b_port": b_port,
        "cable_type": (payload.get("cable_type") or "LC").strip(),
        "note": payload.get("note"),
        "created_by": payload.get("created_by")
    })

    # Markiere Ziel-Port belegt
    connected_to = f"manual:{a_id}:{a_port}"
    db.execute(text("""
        UPDATE patchpanel_ports
        SET status = 'connected',
            connected_to = :ct
        WHERE patchpanel_id = :pid AND port_label = :lbl
    """), {"ct": connected_to, "pid": panel.id, "lbl": b_port})

    db.commit()

    return {
        "success": True,
        "saved": {
            "a_patchpanel_id": a_id,
            "a_port": a_port,
            "b_instance_id": b_iid,
            "b_port_label": b_port,
            "b_room": panel.room
        }
    }


# =========================================================
# EXISTING ENDPOINTS (Switch/Rooms)
# =========================================================

@router.get("/rooms", response_model=list[str])
def read_all_rooms(db: Session = Depends(get_db)):
    return get_all_rooms(db)

@router.get("/room/{room_name}", response_model=RoomOverview)
def read_room_overview(room_name: str, db: Session = Depends(get_db)):
    return get_room_overview(db, room_name)

@router.get("/switch/{switch_name}")
def read_switch_details(switch_name: str, db: Session = Depends(get_db)):
    return get_switch_details(db, switch_name)

@router.get("/room/{room_name}/switches", response_model=list[str])
def read_switches_in_room(room_name: str, db: Session = Depends(get_db)):
    return get_switches_in_room(db, room_name)

@router.get("/stats")
def read_precabling_stats(db: Session = Depends(get_db)):
    return get_precabling_stats(db)

@router.get("/health")
def rackview_health():
    return {"status": "healthy", "service": "rackview-api"}
import re as _re

def _room_norm_variants(room: str):
    """Return normalized variants for matching rooms like 5.04S6 vs 5.4S6 and optional leading M."""
    if not room:
        return []
    s = str(room).strip()
    # remove spaces
    s = s.replace(" ", "")
    # strip leading 'Room' etc not expected but safe
    # remove leading M for parsing
    core0 = s[1:] if s.upper().startswith("M") and len(s) > 1 else s
    m = _re.match(r"^(\d+)\.(\d+)(S\d+)?$", core0, flags=_re.IGNORECASE)
    cores = []
    if m:
        major = m.group(1)
        minor = m.group(2)
        cage = m.group(3) or ""
        keep = f"{major}.{minor}{cage}"
        strip = f"{major}.{int(minor)}{cage}"
        cores = [keep]
        if strip != keep:
            cores.append(strip)
    else:
        cores = [core0]
    out = []
    for c in cores:
        out.append(c)
        out.append("M" + c)
    # normalize to alnum uppercase
    norms = []
    seen=set()
    for v in out:
        n = _re.sub(r"[^A-Z0-9]", "", v.upper())
        if n and n not in seen:
            seen.add(n)
            norms.append(n)
    return norms



