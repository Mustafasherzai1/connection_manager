from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from database import get_db
from security import (
    authenticate_user,
    create_access_token,
    get_current_user,
    get_effective_permissions,
    normalize_role,
)


router = APIRouter(prefix="/auth", tags=["auth"])


class LoginIn(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=1, max_length=200)


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    permissions: list[str] = []


class UserOut(BaseModel):
    id: int
    username: str
    role: str
    is_active: bool
    permissions: list[str] = []


@router.post("/login", response_model=TokenOut)
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = authenticate_user(db, payload.username, payload.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token = create_access_token(
        subject=user["username"],
        role=user["role"],
        user_id=user["id"],
    )
    perms = sorted(get_effective_permissions(db, user))
    return {
        "access_token": token,
        "token_type": "bearer",
        "role": normalize_role(user.get("role")),
        "permissions": perms,
    }


@router.get("/me", response_model=UserOut)
def me(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    perms = sorted(get_effective_permissions(db, current_user))
    return {
        "id": current_user["id"],
        "username": current_user["username"],
        "role": normalize_role(current_user.get("role")),
        "is_active": bool(current_user.get("is_active", True)),
        "permissions": perms,
    }
