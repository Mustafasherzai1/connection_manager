from __future__ import annotations

import re
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query
from sqlalchemy import text
from sqlalchemy.orm import Session

from config import settings
from database import get_db
from security import get_current_user


router = APIRouter(prefix=settings.api_prefix, tags=["patchpanels"])


def _derive_room(row: dict[str, Any]) -> str:
    room = str(row.get("room") or row.get("room_code") or "").strip()
    if room:
        return room

    instance_id = str(row.get("instance_id") or "").strip()
    if "/" in instance_id:
        left = instance_id.split("/", 1)[0].strip()
        if left:
            return left
    return instance_id


def _parse_port_int(value: Any) -> int | None:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    if raw.isdigit():
        return int(raw)
    match = re.search(r"\d+", raw)
    if not match:
        return None
    try:
        return int(match.group(0))
    except Exception:
        return None


def _normalize_ports_total(raw_total: Any, known_port_count: int, occupied_labels: list[str]) -> int:
    if raw_total is not None:
        try:
            total = int(raw_total)
            if total <= 0:
                raise ValueError
            if total <= 48:
                return 48
            if total <= 96:
                return 96
            return total
        except Exception:
            pass

    if known_port_count > 0:
        return 48 if known_port_count <= 48 else 96

    parsed = [_parse_port_int(label) for label in occupied_labels]
    parsed = [x for x in parsed if x is not None]
    max_seen = max(parsed) if parsed else 0
    if max_seen <= 48:
        return 48
    return 96


@router.get("/patchpanels")
def list_patchpanels(
    room: str | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    rows = db.execute(
        text(
            """
            SELECT
                id,
                instance_id,
                room,
                room_code,
                rack_label,
                cage_no,
                total_ports
            FROM public.patchpanel_instances
            ORDER BY COALESCE(room, room_code, ''), COALESCE(rack_label, ''), COALESCE(instance_id, ''), id
            """
        )
    ).mappings().all()

    selected_room = str(room or "").strip().lower()
    items = []
    for row in rows:
        room_name = _derive_room(dict(row))
        if selected_room and room_name.lower() != selected_room:
            continue

        rack = (row.get("rack_label") or "").strip()
        cage = (row.get("cage_no") or "").strip()
        parts = [x for x in [room_name, rack, cage] if x]
        location = " / ".join(parts) if parts else None

        items.append(
            {
                "id": int(row["id"]),
                "name": row.get("instance_id") or f"Patchpanel {row['id']}",
                "room": room_name or None,
                "location": location,
                "ports_total": _normalize_ports_total(row.get("total_ports"), 0, []),
            }
        )

    return {"success": True, "items": items}


@router.get("/patchpanels/rooms")
def list_patchpanel_rooms(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    rows = db.execute(
        text(
            """
            SELECT
                instance_id,
                room,
                room_code
            FROM public.patchpanel_instances
            """
        )
    ).mappings().all()

    rooms = sorted({r for r in (_derive_room(dict(row)) for row in rows) if r})
    return {"success": True, "rooms": rooms}


@router.get("/patchpanels/{pp_id}/ports")
def patchpanel_ports(
    pp_id: int = Path(..., ge=1),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    panel = db.execute(
        text(
            """
            SELECT
                id,
                instance_id,
                room,
                room_code,
                rack_label,
                cage_no,
                total_ports
            FROM public.patchpanel_instances
            WHERE id = :id
            LIMIT 1
            """
        ),
        {"id": int(pp_id)},
    ).mappings().first()
    if not panel:
        raise HTTPException(status_code=404, detail="Patchpanel not found")

    port_rows = db.execute(
        text(
            """
            SELECT
                port_label,
                row_number,
                row_letter,
                position,
                COALESCE(status, 'free') AS base_status,
                connected_to,
                peer_instance_id,
                peer_port_label
            FROM public.patchpanel_ports
            WHERE patchpanel_id = :ppid
            ORDER BY row_number NULLS LAST, row_letter NULLS LAST, position NULLS LAST, port_label
            """
        ),
        {"ppid": int(pp_id)},
    ).mappings().all()

    panel_instance_id = str(panel.get("instance_id") or "").strip()
    occupied_rows = db.execute(
        text(
            """
            WITH occupied AS (
                SELECT
                    customer_port_label AS port_label,
                    serial,
                    COALESCE(system_name, '') AS customer,
                    'Z' AS side,
                    id AS cross_connect_id
                FROM public.cross_connects
                WHERE COALESCE(status, '') <> 'deinstalled'
                  AND customer_patchpanel_id = :ppid
                  AND customer_port_label IS NOT NULL

                UNION ALL

                SELECT
                    a_port_label AS port_label,
                    serial,
                    COALESCE(system_name, '') AS customer,
                    'A' AS side,
                    id AS cross_connect_id
                FROM public.cross_connects
                WHERE COALESCE(status, '') <> 'deinstalled'
                  AND a_port_label IS NOT NULL
                  AND (
                    a_patchpanel_id = :ppid_text
                    OR a_patchpanel_id = :instance_id
                  )

                UNION ALL

                SELECT
                    backbone_in_port_label AS port_label,
                    serial,
                    COALESCE(system_name, '') AS customer,
                    'BB_IN' AS side,
                    id AS cross_connect_id
                FROM public.cross_connects
                WHERE COALESCE(status, '') <> 'deinstalled'
                  AND backbone_in_port_label IS NOT NULL
                  AND backbone_in_instance_id = :instance_id

                UNION ALL

                SELECT
                    backbone_out_port_label AS port_label,
                    serial,
                    COALESCE(system_name, '') AS customer,
                    'BB_OUT' AS side,
                    id AS cross_connect_id
                FROM public.cross_connects
                WHERE COALESCE(status, '') <> 'deinstalled'
                  AND backbone_out_port_label IS NOT NULL
                  AND backbone_out_instance_id = :instance_id
            )
            SELECT
                port_label,
                serial,
                customer,
                side,
                cross_connect_id
            FROM occupied
            WHERE port_label IS NOT NULL AND TRIM(port_label) <> ''
            """
        ),
        {"ppid": int(pp_id), "ppid_text": str(pp_id), "instance_id": panel_instance_id},
    ).mappings().all()

    occupied_by_label: dict[str, dict[str, Any]] = {}
    ordered_occupied_labels: list[str] = []
    for row in occupied_rows:
        label = str(row.get("port_label") or "").strip()
        if not label:
            continue
        key = label.lower()
        if key in occupied_by_label:
            continue
        occupied_by_label[key] = {
            "serial": row.get("serial"),
            "customer": row.get("customer") or None,
            "side": row.get("side"),
            "cross_connect_id": int(row.get("cross_connect_id")) if row.get("cross_connect_id") is not None else None,
        }
        ordered_occupied_labels.append(label)

    labels: list[str] = []
    port_meta_by_label: dict[str, dict[str, Any]] = {}
    seen = set()
    for row in port_rows:
        label = str(row.get("port_label") or "").strip()
        if not label:
            continue
        key = label.lower()
        if key in seen:
            continue
        seen.add(key)
        labels.append(label)
        port_meta_by_label[key] = {
            "peer_instance_id": row.get("peer_instance_id"),
            "peer_port_label": row.get("peer_port_label"),
            "connected_to": row.get("connected_to"),
            "base_status": str(row.get("base_status") or "free").strip().lower(),
        }

    ports_total = _normalize_ports_total(panel.get("total_ports"), len(labels), ordered_occupied_labels)

    if not labels:
        labels = [str(i) for i in range(1, ports_total + 1)]
    elif len(labels) < ports_total:
        numeric_seen = {str(_parse_port_int(x)) for x in labels if _parse_port_int(x) is not None}
        i = 1
        while len(labels) < ports_total:
            key = str(i)
            if key not in numeric_seen:
                labels.append(key)
                numeric_seen.add(key)
            i += 1
    elif len(labels) > ports_total:
        ports_total = len(labels)

    ports = []
    has_real_port_rows = len(port_rows) > 0
    for idx in range(ports_total):
        label = labels[idx] if idx < len(labels) else str(idx + 1)
        key = label.lower()
        occ = occupied_by_label.get(label.lower())
        meta = port_meta_by_label.get(key) or {}
        synthetic_unavailable = has_real_port_rows and key not in port_meta_by_label
        base_status = str(meta.get("base_status") or "free").lower()
        if synthetic_unavailable:
            normalized_status = "unavailable"
        else:
            normalized_status = "occupied" if occ else base_status
            if normalized_status in {"connected", "linked", "precabled"}:
                normalized_status = "free"
            if normalized_status in {"used", "consumed", "busy", "in_use"}:
                normalized_status = "occupied"
            if normalized_status not in {"occupied", "free", "unavailable"}:
                normalized_status = "free"

        legacy_occupied = bool(occ) or synthetic_unavailable

        ports.append(
            {
                "port_number": idx + 1,
                "port_label": label,
                "status": normalized_status,
                "occupied": legacy_occupied,
                "selectable": not legacy_occupied and normalized_status != "unavailable",
                "usable": normalized_status != "unavailable",
                "connected_to": meta.get("connected_to"),
                "peer_instance_id": meta.get("peer_instance_id"),
                "peer_port_label": meta.get("peer_port_label"),
                "is_occupied": bool(occ),
                # If no dedicated trunk table exists, occupancy is used as trunk indicator.
                "trunk_present": bool(occ),
                "trunk_id": None,
                "trunk_label": None,
                "serial": (occ or {}).get("serial"),
                "customer": (occ or {}).get("customer"),
                "side": (occ or {}).get("side"),
                "cross_connect_id": (occ or {}).get("cross_connect_id"),
            }
        )

    room = (panel.get("room") or panel.get("room_code") or "").strip()
    rack = (panel.get("rack_label") or "").strip()
    cage = (panel.get("cage_no") or "").strip()
    parts = [x for x in [room, rack, cage] if x]
    location = " / ".join(parts) if parts else None

    return {
        "success": True,
        "patchpanel": {
            "id": int(panel["id"]),
            "name": panel.get("instance_id") or f"Patchpanel {panel['id']}",
            "location": location,
            "ports_total": int(ports_total),
        },
        "ports_total": int(ports_total),
        "ports": ports,
        "slots": [],
    }
